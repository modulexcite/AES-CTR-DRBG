﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace Drbg_Test
{
    internal static class SecureRandom
    {
        #region Constants
        private const int INT_SIZE = 4;
        private const int INT64_SIZE = 8;
        #endregion

        #region Fields
        private static readonly RNGCryptoServiceProvider _Random;
        #endregion

        #region Constructor
        static SecureRandom()
        {
            _Random = new RNGCryptoServiceProvider();
        }
        #endregion

        #region Random Int32
        /// <summary>
        /// Get the next random integer
        /// </summary>
        /// <returns>Random [Int32]</returns>
        internal static Int32 Next()
        {
            byte[] data = new byte[INT_SIZE];
            Int32[] result = new Int32[1];

            _Random.GetBytes(data);
            Buffer.BlockCopy(data, 0, result, 0, INT_SIZE);

            return result[0];
        }

        /// <summary>
        /// Get the next random integer to a maximum value
        /// </summary>
        /// <param name="MaxValue">Maximum value</param>
        /// <returns>Random [Int32]</returns>
        internal static Int32 Next(Int32 MaxValue)
        {
            Int32 result = 0;

            do
            {
                result = Next();
            } while (result > MaxValue);

            return result;
        }
        #endregion

        #region Random UInt32
        /// <summary>
        /// Get the next random unsigned integer
        /// </summary>
        /// <returns>Random [UInt32]</returns>
        internal static UInt32 NextUInt()
        {
            byte[] data = new byte[INT_SIZE];
            Int32[] result = new Int32[1];

            do
            {
                _Random.GetBytes(data);
                Buffer.BlockCopy(data, 0, result, 0, INT_SIZE);
            } while (result[0] < 0);

            return (UInt32)result[0];
        }

        /// <summary>
        /// Get the next random unsigned integer to a maximum value
        /// </summary>
        /// <param name="MaxValue">Maximum value</param>
        /// <returns>Random [UInt32]</returns>
        internal static UInt32 NextUInt(UInt32 MaxValue)
        {
            UInt32 result = 0;

            do
            {
                result = NextUInt();
            } while (result > MaxValue);

            return result;
        }
        #endregion

        #region Random Int64
        /// <summary>
        /// Get the next random integer
        /// </summary>
        /// <returns>Random [Int32]</returns>
        internal static Int64 NextLong()
        {
            byte[] data = new byte[INT64_SIZE];
            Int64[] result = new Int64[1];

            _Random.GetBytes(data);
            Buffer.BlockCopy(data, 0, result, 0, INT64_SIZE);

            return result[0];
        }

        /// <summary>
        /// Get the next random unsigned long to a maximum value
        /// </summary>
        /// <param name="MaxValue">Maximum value</param>
        /// <returns>Random [UInt64]</returns>
        internal static Int64 NextLong(Int64 MaxValue)
        {
            Int64 result = 0;

            do
            {
                result = NextLong();
            } while (result > MaxValue);

            return result;
        }
        #endregion

        #region Random UInt64
        /// <summary>
        /// Get the next random unsigned long
        /// </summary>
        /// <returns>Random [UInt64]</returns>
        internal static UInt64 NextULong()
        {
            byte[] data = new byte[INT64_SIZE];
            Int64[] result = new Int64[1];

            do
            {
                _Random.GetBytes(data);
                Buffer.BlockCopy(data, 0, result, 0, INT64_SIZE);
            } while (result[0] < 0);

            return (UInt64)result[0];
        }

        /// <summary>
        /// Get the next random unsigned long to a maximum value
        /// </summary>
        /// <param name="MaxValue">Maximum value</param>
        /// <returns>Random [UInt64]</returns>
        internal static UInt64 NextULong(UInt64 MaxValue)
        {
            UInt64 result = 0;

            do
            {
                result = NextULong();
            } while (result > MaxValue);

            return result;
        }
        #endregion

        #region Random Bytes
        /// <summary>
        /// Get random bytes
        /// </summary>
        /// <param name="data">Random [byte array]</param>
        internal static byte[] NextBytes(long Size)
        {
            byte[] data = new byte[Size];
            _Random.GetBytes(data);

            return data;
        }

        private static SHA256 _shaHash = SHA256Managed.Create();
        internal static byte[] GetKey()
        {
            byte[] data = new byte[32];
            _Random.GetBytes(data);

            return _shaHash.ComputeHash(data);
        }

        internal static byte[] GetIv()
        {
            byte[] data = new byte[32];
            byte[] iv = new byte[16];

            _Random.GetBytes(data);

            Buffer.BlockCopy(_shaHash.ComputeHash(data), 0, iv, 0, 16);
            return iv;
        }

        internal static byte[] GetSeed()
        {
            byte[] data = new byte[64];
            Buffer.BlockCopy(GetKey(), 0, data, 0, 32);
            Buffer.BlockCopy(GetKey(), 0, data, 32, 32);
            return data;
        }

        internal static byte[] GetSeed384()
        {
            byte[] data = new byte[48];
            Buffer.BlockCopy(GetKey(), 0, data, 0, 32);
            Buffer.BlockCopy(GetIv(), 0, data, 32, 16);
            return data;
        }

        private const int INTEGER_SIZE = 4;

        internal static byte[] BlockBuilder(UInt32 Length)
        {
            byte[] key = GetKey();
            byte[] iv = GetIv();
            uint position = NextUInt(uint.MaxValue - 1024);

            using (AesCbc enc = new AesCbc(true, key, iv))
                return enc.Encrypt(MontonicArray(position, Length));
        }

        /// <summary>
        /// Get a stack of integers
        /// </summary>
        /// <param name="Position">Starting position of array</param>
        /// <param name="Length">length of the array</param>
        /// <returns>Array [byte array]</returns>
        private static byte[] MontonicArray(UInt32 Position, UInt32 Length)
        {
            UInt32[] stack = new UInt32[Length];
            UInt32 count = 0;

            do
            {
                stack[count] = Position + count;
                count++;

            } while (count < Length);

            byte[] data = new byte[stack.Length * INTEGER_SIZE];
            Buffer.BlockCopy(stack, 0, data, 0, data.Length);

            return data;
        }
        #endregion
    }
}
