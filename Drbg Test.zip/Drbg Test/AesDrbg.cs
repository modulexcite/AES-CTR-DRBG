﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace Drbg_Test
{
    /// <summary>
    /// A SP800-90A CTR DRBG.
    /// </summary>
    public class AesDrbg
    {
        private byte[] _Key;
        private byte[] _IV;
        private const Int32 KEY_LENGTH = 256;
        private const Int32 BLOCK_SIZE = 16;
        private const Int32 KEY_SIZE = 32;
        private const Int32 SEED_LENGTH = 384;
        private static readonly byte[] KBITS = new byte[] { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
			0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f };

        public AesDrbg(byte[] Key, byte[] Iv, byte[] Seed)
        {
            _Key = new byte[KEY_SIZE];
            _IV = new byte[BLOCK_SIZE];
            Init(Seed);
        }

        private void Init(byte[] Seed)
        {
            byte[] derSeed = Derive(Seed, SEED_LENGTH);
            Update(derSeed, _Key, _IV);
        }
        /*private void CTR_DRBG_Update(byte[] seed, byte[] key, byte[] v)
        {
            byte[] temp = new byte[seed.length];
            byte[] outputBlock = new byte[_engine.getBlockSize()];

            int i = 0;
            int outLen = _engine.getBlockSize();


            _engine.init(true, new KeyParameter(expandKey(key)));
            while (i * outLen < seed.length)
            {
                addOneTo(v);
                _engine.processBlock(v, 0, outputBlock, 0);


                int bytesToCopy = ((temp.length - i * outLen) > outLen)
                        ? outLen : (temp.length - i * outLen);

                System.arraycopy(outputBlock, 0, temp, i * outLen, bytesToCopy);
                ++i;
            }


            XOR(temp, seed, temp, 0);


            System.arraycopy(temp, 0, key, 0, key.length);
            System.arraycopy(temp, key.length, v, 0, v.length);
        }*/

        private void Update(byte[] seed, byte[] key, byte[] iv)
        {
            byte[] temp = new byte[seed.Length];
            byte[] outputBlock = new byte[BLOCK_SIZE];

            int i = 0;
            int outLen = BLOCK_SIZE;

            using (AesCtr fa = new AesCtr(key, iv))
            {
                while (i * outLen < seed.Length)
                {
                    Increment(iv);
                    outputBlock = fa.Transform(iv);
                    int bytesToCopy = ((temp.Length - i * outLen) > outLen) ? outLen : (temp.Length - i * outLen);
                    System.Array.Copy(outputBlock, 0, temp, i * outLen, bytesToCopy);
                    ++i;
                }
            }




            Xor(temp, seed, temp, 0);
            System.Array.Copy(temp, 0, key, 0, key.Length);
            System.Array.Copy(temp, key.Length, iv, 0, iv.Length);
        }

        private void Xor(byte[] bout, byte[] a, byte[] b, int bOff)
        {
            for (int i = 0; i < bout.Length; i++)
                bout[i] = (byte)(a[i] ^ b[i + bOff]);
        }

        private void Increment(byte[] Data)
        {
            int carry = 1;
            for (int i = 1; i <= Data.Length; i++)
            {
                int res = (Data[Data.Length - i] & 0xff) + carry;
                carry = (res > 0xff) ? 1 : 0;
                Data[Data.Length - i] = (byte)res;
            }
        }

        private byte[] Derive(byte[] inputData, int bitLength)
        {
            int inputLen = inputData.Length;
            int byteLen = bitLength / 8;
            int sLen = 4 + 4 + inputLen + 1;
            int blockLen = ((sLen + BLOCK_SIZE - 1) / BLOCK_SIZE) * BLOCK_SIZE;
            byte[] data = new byte[blockLen];
            IntToByteArray(data, inputLen, 0);
            IntToByteArray(data, byteLen, 4);
            System.Array.Copy(inputData, 0, data, 8, inputLen);
            data[8 + inputLen] = (byte)0x80;
            byte[] temp = new byte[KEY_LENGTH / 8 + BLOCK_SIZE];
            byte[] bccOut = new byte[BLOCK_SIZE];
            int i = 0;
            byte[] iv = new byte[BLOCK_SIZE];
            byte[] key = new byte[KEY_SIZE];
            System.Array.Copy(KBITS, 0, key, 0, key.Length);

            while (i * BLOCK_SIZE * 8 < KEY_LENGTH + BLOCK_SIZE * 8)
            {
                IntToByteArray(iv, i, 0);
                ChainBlock(bccOut, key, iv, data);

                int bytesToCopy = ((temp.Length - i * BLOCK_SIZE) > BLOCK_SIZE) ? BLOCK_SIZE : (temp.Length - i * BLOCK_SIZE);
                System.Array.Copy(bccOut, 0, temp, i * BLOCK_SIZE, bytesToCopy);
                ++i;
            }

            byte[] btOut = new byte[BLOCK_SIZE];
            System.Array.Copy(temp, 0, key, 0, key.Length);
            System.Array.Copy(temp, key.Length, btOut, 0, btOut.Length);
            temp = new byte[bitLength / 2];
            i = 0;

            using (AesCtr fa = new AesCtr(key, iv))
            {
                while (i * BLOCK_SIZE < temp.Length)
                {
                    btOut = fa.Transform(btOut);
                    int bytesToCopy = ((temp.Length - i * BLOCK_SIZE) > BLOCK_SIZE) ? BLOCK_SIZE : (temp.Length - i * BLOCK_SIZE);
                    System.Array.Copy(btOut, 0, temp, i * BLOCK_SIZE, bytesToCopy);
                    i++;
                }
            }

            return temp;
        }
 
        private void ChainBlock(byte[] bccOut, byte[] key, byte[] iv, byte[] data)
        {
            byte[] chainingValue = new byte[BLOCK_SIZE];
            int dataLen = data.Length / BLOCK_SIZE;
            byte[] inputBlock = new byte[BLOCK_SIZE];

            using (AesCtr fa = new AesCtr(key, iv))
            {
                chainingValue = fa.Transform(iv);
                for (int i = 0; i < dataLen; i++)
                {
                    Xor(inputBlock, chainingValue, data, i * BLOCK_SIZE);
                    chainingValue = fa.Transform(inputBlock);
                }
            }

            System.Array.Copy(chainingValue, 0, bccOut, 0, bccOut.Length);
        }

        private void IntToByteArray(byte[] buffer, int value, int offSet)
        {
            buffer[offSet + 0] = ((byte)(value >> 24));
            buffer[offSet + 1] = ((byte)(value >> 16));
            buffer[offSet + 2] = ((byte)(value >> 8));
            buffer[offSet + 3] = ((byte)(value));
        }

        public int Generate(byte[] output)
        {
            byte[] bout = new byte[BLOCK_SIZE];

            using (AesCtr fa = new AesCtr(_Key, _IV))
            {
                for (int i = 0; i < output.Length / bout.Length; i++)
                {
                    Increment(_IV);
                    bout = fa.Transform(_IV);
                    int bytesToCopy = ((output.Length - i * bout.Length) > bout.Length) ? bout.Length : (output.Length - i * _IV.Length);
                    System.Array.Copy(bout, 0, output, i * bout.Length, bytesToCopy);
                }
            }
            return output.Length * 8;
        }
    }
}
