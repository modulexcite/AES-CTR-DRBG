﻿using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Windows.Forms;
using System.Diagnostics;

namespace Drbg_Test
{
    public partial class Form1 : Form
    {
        #region Enums
        private enum ApiTypes
        {
            Aes,
            Drbg,
            Rng,
        }

        private enum TestTypes : int
        {
            Entropy = 0,
            ChiSquare,
            ChiProbability,
            Mean,
            MonteCarloErrorPct,
            MonteCarloPiCalc,
            SerialCorrelation,
        }
        #endregion

        #region Constants
        // output random to file path
        private const string RANDOMOUT_PATH = @"C:\Tests\random.bin";
        // results file name
        private const string RESULTS_NAME = "results.txt";
        #endregion

        #region Fields
        private int Iterations = 1000;
        private int SampleSize = 102400;
        private string _dlgPath = string.Empty;
        private StreamWriter _dataWriter;
        private RNGCryptoServiceProvider _rngRandom = new RNGCryptoServiceProvider();
        private ApiTypes _Opponent = ApiTypes.Rng;
        private Stopwatch _runTimer = new Stopwatch();
        private double _milliSecondsAes = 0;
        private double _milliSecondsOpponent = 0;
        #endregion

        #region Constructor
        public Form1()
        {
            InitializeComponent();
            btnTestAesCtr.Enabled = false;
            txtOutput.Text = "[Select a Destination Folder]";

            // test instance equality (throws on fail)
            CompareEqual();
            // test methods (throws on exception, output to debug window)
            TestOutputs();
            // test speed between algorithms (output to debug window)
            CompareSpeed(1024000);
            // unrem to write 10Mib AesCtr autoseed mode
            //Write(GetRandomAutoSeed(102400000), RANDOMOUT_PATH);
            // unrem to write 10Mib AesCtr oscillating mode
            //Write(GetRandomOscillating(102400000), RANDOMOUT_PATH);
            // unrem to write 10Mib AesCtr rotating mode
            //Write(GetRandomRotating(102400000), RANDOMOUT_PATH);
            // unrem to write 10Mib Aes800Drbg
            //Write(GetAes800Drbg(102400000), RANDOMOUT_PATH);
            // unrem to write 10Mib RNGCryptoServiceProvider
            //Write(GetRNGRandom(102400000), RANDOMOUT_PATH);
        }
        #endregion

        #region Controls
        private void OnCheckChanged(object sender, EventArgs e)
        {
            if (File.Exists(txtOutput.Text))
                File.Delete(txtOutput.Text);
            if (Directory.Exists(Path.GetDirectoryName(txtOutput.Text)))
                btnTestAesCtr.Enabled = true;
        }

        private void OnDialogClick(object sender, EventArgs e)
        {
            btnTestAesCtr.Enabled = false;
            txtOutput.Text = "[Select a Destination Folder]";
            pbStatus.Value = 0;
            lblStatAes.Text = "....";
            lblStatOpponent.Text = "....";

            using (FolderBrowserDialog fbDiag = new FolderBrowserDialog())
            {
                fbDiag.Description = "Select a Folder";

                if (fbDiag.ShowDialog() == DialogResult.OK)
                {
                    if (Directory.Exists(fbDiag.SelectedPath))
                        _dlgPath = Path.Combine(fbDiag.SelectedPath, RESULTS_NAME);
                    if (File.Exists(_dlgPath))
                        File.Delete(_dlgPath);

                    txtOutput.Text = _dlgPath;
                    btnTestAesCtr.Enabled = true;
                }
            }
        }

        private void OnSelectedValueChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;
            if (cb == null) return;
            if (cb.SelectedItem == null) return;
            
            if (cb.Name == "cbTestIterations")
            {
                int sampleCount = 0;
                int.TryParse(cb.SelectedItem.ToString(), out sampleCount);
                if (sampleCount < 1) return;
                this.Iterations = sampleCount;
            }
            else
            {
                int sampleSize = 0;
                int.TryParse(cb.SelectedItem.ToString(), out sampleSize);
                if (sampleSize < 1) return;
                this.SampleSize = sampleSize * 1024;
            }

            int sum = this.Iterations * this.SampleSize;

            if (sum > 102400000)
                MessageBox.Show("That is " + sum.ToString() + "Kib.. This could take a long time to calculate..", "AesCtr", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void OnTestClick(object sender, EventArgs e)
        {
            if (!Directory.Exists(Path.GetDirectoryName(_dlgPath))) return;
            if (this.Iterations < 1 || this.SampleSize < 1) return;

            _Opponent = rdRng.Checked ? ApiTypes.Rng : ApiTypes.Drbg;
            lblStatAes.Text = "....";
            lblStatOpponent.Text = "....";
            _milliSecondsOpponent = 0;
            _milliSecondsAes = 0;
            // set up the controls
            pbStatus.Maximum = Iterations;
            pbStatus.Value = 0;
            lblStatus.Text = "Processing 2 * " + (this.Iterations * this.SampleSize).ToString() + " bytes..";
            lblStatus.Update();
            btnTestAesCtr.Enabled = false;
            grpOutput.Enabled = false;
            grpModes.Enabled = false;
            grpChoice.Enabled = false;
            grpParamaters.Enabled = false;
            this.Update();

            if (File.Exists(_dlgPath))
                File.Delete(_dlgPath);

            // run the compare
            using (_dataWriter = File.AppendText(_dlgPath))
                CompareApi(Iterations, _dlgPath, false);

            // timed
            lblStatAes.Text = "Aes: " + TimeSpan.FromMilliseconds(_milliSecondsAes).ToString(@"m\:ss\.ff") + " seconds";
            lblStatOpponent.Text = _Opponent.ToString() + ": " + TimeSpan.FromMilliseconds(_milliSecondsOpponent).ToString(@"m\:ss\.ff") + " seconds";
            // enable and notify
            grpOutput.Enabled = true;
            grpModes.Enabled = true;
            grpChoice.Enabled = true;
            grpParamaters.Enabled = true;
            lblStatus.Text = "Completed!";
            pbStatus.Value = Iterations;
        }
        #endregion

        #region Tests
        private void CompareApi(int Iterations, string Path, bool SummaryOnly = false)
        {
            int percentA = 0;
            int percentR = 0;
            double entropyAvgA = 0;
            double entropyAvgR = 0;
            double chiProbA = 0;
            double chiProbR = 0;
            double chiSquareA = 0;
            double chiSquareR = 0;
            double montePiA = 0;
            double montePiR = 0;
            double monteErrA = 0;
            double monteErrR = 0;
            double meanA = 0;
            double meanR = 0;
            double serA = 0;
            double serR = 0;
            int chiProbWon = 0;
            int chiSquareWon = 0;
            int meanWon = 0;
            int monteErrWon = 0;
            int montePiWon = 0;
            int serCorWon = 0;
            ApiTypes api = ApiTypes.Aes;
            EntResult res1;
            EntResult res2;
            Ent ent1 = new Ent();
            Ent ent2 = new Ent();

            for (int i = 0; i < Iterations; i++)
            {
                if (rdRotating.Checked)
                    res1 = ent1.Calculate(GetRandomRotating(SampleSize));
                else if (rdOscillating.Checked)
                    res1 = ent1.Calculate(GetRandomOscillating(SampleSize));
                else if (rdCtrChain.Checked)
                    res1 = ent1.Calculate(GetRandomCtr(SampleSize));
                else
                    res1 = ent1.Calculate(GetRandomAutoSeed(SampleSize));

                if (rdAes800.Checked)
                    res2 = ent2.Calculate(GetAes800Drbg(SampleSize));
                else
                    res2 = ent2.Calculate(GetRNGRandom(SampleSize));

                ApiTypes bestPerc = EntCompare(res1, res2, TestTypes.Entropy);

                if (bestPerc == ApiTypes.Aes)
                    percentA++;
                else
                    percentR++;

                chiProbA += res1.ChiProbability;
                chiProbR += res2.ChiProbability;
                chiSquareA += res1.ChiSquare;
                chiSquareR += res2.ChiSquare;
                entropyAvgA += res1.Entropy;
                entropyAvgR += res2.Entropy;
                monteErrA += res1.MonteCarloErrorPct;
                monteErrR += res2.MonteCarloErrorPct;
                montePiA += res1.MonteCarloPiCalc;
                montePiR += res2.MonteCarloPiCalc;
                meanA += res1.Mean;
                meanR += res2.Mean;
                serA += res1.SerialCorrelation;
                serR += res2.SerialCorrelation;

                // flag the test winner (A or R)
                if (!SummaryOnly) Append("Entropy Alg:" + bestPerc.ToString() + " AesCtr:" + res1.Entropy.ToString() + " RngApi: " + res2.Entropy.ToString(), Path);

                api = EntCompare(res1, res2, TestTypes.ChiProbability);
                if (api == ApiTypes.Aes) chiProbWon++;
                if (!SummaryOnly) Append("ChiProbability: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.ChiSquare);
                if (api == ApiTypes.Aes) chiSquareWon++;
                if (!SummaryOnly) Append("ChiSquare: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.Mean);
                if (api == ApiTypes.Aes) meanWon++;
                if (!SummaryOnly) Append("Mean: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.MonteCarloErrorPct);
                if (api == ApiTypes.Aes) monteErrWon++;
                if (!SummaryOnly) Append("MonteCarloErrorPct: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.MonteCarloPiCalc);
                if (api == ApiTypes.Aes) montePiWon++;
                if (!SummaryOnly) Append("MonteCarloPiCalc: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.SerialCorrelation);
                if (api == ApiTypes.Aes) serCorWon++;
                if (!SummaryOnly) Append("SerialCorrelation: " + api.ToString(), Path);
                if (!SummaryOnly) Append(" ", Path);

                if (!SummaryOnly)
                {
                    // Aes scores
                    Append("AesCtr", Path);
                    Append("ChiProbability: " + res1.ChiProbability.ToString(), Path);
                    Append("ChiSquare: " + res1.ChiSquare.ToString(), Path);
                    Append("Mean: " + res1.Mean.ToString(), Path);
                    Append("MonteCarloErrorPct: " + res1.MonteCarloErrorPct.ToString(), Path);
                    Append("MonteCarloPiCalc: " + res1.MonteCarloPiCalc.ToString(), Path);
                    Append("SerialCorrelation: " + res1.SerialCorrelation.ToString(), Path);
                    Append(" ", Path);
                    // rng scores
                    if (!SummaryOnly) Append("RngApi", Path);
                    Append("ChiProbability: " + res2.ChiProbability.ToString(), Path);
                    Append("ChiSquare: " + res2.ChiSquare.ToString(), Path);
                    Append("Mean: " + res2.Mean.ToString(), Path);
                    Append("MonteCarloErrorPct: " + res2.MonteCarloErrorPct.ToString(), Path);
                    Append("MonteCarloPiCalc: " + res2.MonteCarloPiCalc.ToString(), Path);
                    Append("SerialCorrelation: " + res2.SerialCorrelation.ToString(), Path);
                    Append("#######################################################", Path);
                    Append(" ", Path);
                }
                pbStatus.Value = i;
                ent1.Reset();
                ent2.Reset();
            }

            // get the averages
            int sumA = chiProbWon + chiSquareWon + meanWon + monteErrWon + montePiWon + serCorWon;
            int sumR = (Iterations * 6) - sumA;

            Append("Best Overall Entropy: Aes: " + percentA.ToString() + " " + _Opponent.ToString() + ": " + percentR.ToString(), Path);
            Append(" ", Path);
            Append("Entropy Avg: Aes: " + (entropyAvgA / Iterations).ToString() + " " + _Opponent.ToString() + ": " + (entropyAvgR / Iterations).ToString(), Path);
            Append(" ", Path);
            Append("Total Wins of Tests Scored: Aes: " + sumA.ToString() + " " + _Opponent.ToString() + ": " + sumR.ToString(), Path);
            Append(" ", Path);
            Append("ChiProbability Score: Aes: " + chiProbWon.ToString() + " " + _Opponent.ToString() + ": " + (Iterations - chiProbWon).ToString(), Path);
            Append("ChiProbability Avg: Aes: " + (chiProbA / Iterations).ToString() + " " + _Opponent.ToString() + ": " + (chiProbR / Iterations).ToString(), Path);
            Append(" ", Path);
            Append("ChiSquare Score: Aes: " + chiSquareWon.ToString() + " " + _Opponent.ToString() + ": " + (Iterations - chiSquareWon).ToString(), Path);
            Append("ChiSquare Avg: Aes: " + (chiSquareA / Iterations).ToString() + " " + _Opponent.ToString() + ": " + (chiSquareR / Iterations).ToString(), Path);
            Append(" ", Path);
            Append("MonteCarlo Error Score: Aes: " + monteErrWon.ToString() + " " + _Opponent.ToString() + ": " + (Iterations - monteErrWon).ToString(), Path);
            Append("MonteCarlo Error Avg: Aes: " + (monteErrA / Iterations).ToString() + " " + _Opponent.ToString() + ": " + (monteErrR / Iterations).ToString(), Path);
            Append(" ", Path);
            Append("MonteCarlo Pi Score: Aes: " + montePiWon.ToString() + " " + _Opponent.ToString() + ": " + (Iterations - montePiWon).ToString(), Path);
            Append("MonteCarlo Pi Avg: Aes: " + (montePiA / Iterations).ToString() + " " + _Opponent.ToString() + ": " + (montePiR / Iterations).ToString(), Path);
            Append(" ", Path);
            Append("Mean Score: Aes: " + meanWon.ToString() + " " + _Opponent.ToString() + ": " + (Iterations - meanWon).ToString(), Path);
            Append("Mean Avg: Aes: " + (meanA / Iterations).ToString() + " " + _Opponent.ToString() + ": " + (meanR / Iterations).ToString(), Path);
            Append(" ", Path);
            Append("Serial Correlation Score: Aes: " + serCorWon.ToString() + " " + _Opponent.ToString() + ": " + (Iterations - serCorWon).ToString(), Path);
            Append("Serial Correlation Avg: Aes: " + (serA / Iterations).ToString() + " " + _Opponent.ToString() + ": " + (serR / Iterations).ToString(), Path);

            ent1.Dispose();
            ent2.Dispose();
        }

        private void CompareEqual()
        {
            byte[] data = new byte[1024000];
            byte[] data2 = new byte[1024000];
            byte[] seed = CSPRNG.GetSeed64();

            using (AesCtr ctr = new AesCtr())
                data = ctr.Generate(seed, 1024000);
            using (AesCtr ctr = new AesCtr())
                data2 = ctr.Generate(seed, 1024000);

            if (Equal(data, data2))
                Console.WriteLine("Equality Test: Passed!");
            else
                Console.WriteLine("Equality Test: Failed!");
        }

        private void CompareSpeed(int Size)
        {
            byte[] data = new byte[Size];
            byte[] seed512 = CSPRNG.GetSeed64();
            byte[] seed384 = GetSeed48();
            string state = " created " + Size.ToString() +  " bytes in ";

            // start
            TimerStart();
            // AesCtr
            using (AesCtr random = new AesCtr())
                data = random.Generate(seed512, Size);
            // get results and reset
            Console.WriteLine("AesCtr" + state + TimeSpan.FromMilliseconds(TimerStop()).ToString(@"m\:ss\.ff") + " seconds");

            data = new byte[Size];
            TimerStart();
            // RNGCryptoServiceProvider
            _rngRandom.GetBytes(data);
            Console.WriteLine("RngCrypto" + state + TimeSpan.FromMilliseconds(TimerStop()).ToString(@"m\:ss\.ff") + " seconds");

            data = new byte[Size];
            // Aes800Drbg
            TimerStart();
            Aes800Drbg ctr = new Aes800Drbg(GetSeed48());
            ctr.Generate(data);
            Console.WriteLine("800Drbg" + state + TimeSpan.FromMilliseconds(TimerStop()).ToString(@"m\:ss\.ff") + " seconds");
        }

        private void TestOutputs()
        {
            try
            {
                Console.WriteLine("Testing CPRNG..");
                Console.WriteLine("Double: " + CSPRNG.NextDouble().ToString());
                Console.WriteLine("Float: " + CSPRNG.NextFloat().ToString());
                Console.WriteLine("Int16: " + CSPRNG.NextInt16().ToString());
                Console.WriteLine("UInt16: " + CSPRNG.NextUInt16().ToString());
                Console.WriteLine("Int32: " + CSPRNG.NextInt32().ToString());
                Console.WriteLine("UInt32: " + CSPRNG.NextUInt32().ToString());
                Console.WriteLine("Int64: " + CSPRNG.NextInt64().ToString());
                Console.WriteLine("UInt64: " + CSPRNG.NextUInt64().ToString());

                Console.WriteLine("Testing AesCtr..");
                using (AesCtr random = new AesCtr())
                {
                    Int16[] num16 = new Int16[8];
                    random.GetInt16s(num16);
                    Console.WriteLine("Int16 array: " + string.Join(",", num16));

                    Int32[] num32 = new Int32[8];
                    random.GetInt32s(num32);
                    Console.WriteLine("Int32 array: " + string.Join(",", num32));

                    Int64[] num64 = new Int64[8];
                    random.GetInt64s(num64);
                    Console.WriteLine("Int64 array: " + string.Join(",", num64));

                    byte[] btA = new byte[8];
                    random.GetBytes(btA);
                    Console.WriteLine("byte array: " + string.Join(",", btA));

                    char[] chA = new char[8];
                    random.GetChars(chA);
                    Console.WriteLine("char array: " + string.Join(",", chA));
                }
            }
            catch (Exception ex)
            {
                throw new Exception("TestOutputs() has failed!");
            }
        }
        #endregion

        #region Algorithms
        /// <summary>
        /// Get random using the Aes800Drbg algorithm 
        /// </summary>
        private byte[] GetAes800Drbg(int Size)
        {
            byte[] data = new byte[Size];
            TimerStart();
            Aes800Drbg ctr = new Aes800Drbg(GetSeed48());
            ctr.Generate(data);
            _milliSecondsOpponent += TimerStop();
            return data;
        }

        /// <summary>
        /// Get random using AesCtr in auto seeding mode
        /// </summary>
        private byte[] GetRandomAutoSeed(int Size)
        {
            byte[] data = new byte[Size];
            TimerStart();
            using (AesCtr random = new AesCtr())
                data = random.Generate(Size);
            _milliSecondsAes += TimerStop();
            return data;
        }

        /// <summary>
        /// Get random using AesCtr in key oscillating mode
        /// </summary>
        private byte[] GetRandomOscillating(int Size)
        {
            byte[] data = new byte[Size];
            TimerStart();
            using (AesCtr random = new AesCtr())
                data = random.GenerateOsc(CSPRNG.GetSeed64(), Size);
            _milliSecondsAes += TimerStop();
            return data;
        }

        /// <summary>
        /// Get random using AesCtr in key rotation mode
        /// </summary>
        private byte[] GetRandomRotating(int Size)
        {
            byte[] data = new byte[Size];
            TimerStart();
            using (AesCtr random = new AesCtr())
                data = random.Generate(CSPRNG.GetSeed64(), Size);
            _milliSecondsAes += TimerStop();
            return data;
        }

        /// <summary>
        /// Get random using AesCtr in Ctr chaining mode
        /// </summary>
        private byte[] GetRandomCtr(int Size)
        {
            byte[] data = new byte[Size];
            TimerStart();
            using (AesCtr random = new AesCtr())
                data = random.GenerateCtr(CSPRNG.GetSeed64(), Size);
            _milliSecondsAes += TimerStop();
            return data;
        }

        /// <summary>
        /// Uses the native RNGCryptoServiceProvider algorithm
        /// </summary>
        /// <param name="Size">Size of return in bytes</param>
        /// <returns>Random byte array [byte]]</returns>
        private byte[] GetRNGRandom(int Size)
        {
            byte[] data = new byte[Size];
            TimerStart();
            _rngRandom.GetBytes(data);
            _milliSecondsOpponent += TimerStop();
            return data;
        }
        #endregion
        
        #region Helpers
        private void Append(string Data, string Path)
        {
            _dataWriter.WriteLine(Data);
        }

        private void Write(byte[] Data, string Path)
        {
            using (BinaryWriter writer = new BinaryWriter(File.Open(Path, FileMode.Create)))
                writer.Write(Data);
        }

        private ApiTypes EntCompare(EntResult Res1, EntResult Res2, TestTypes TestType = TestTypes.Entropy)
        {
            const double MEAN = 127.5;
            const double PI = 3.1415926535;

            ApiTypes winner = ApiTypes.Aes;

            switch (TestType)
            {
                case TestTypes.Entropy:
                    {
                        if (Res2.Entropy > Res1.Entropy)
                            winner = _Opponent;
                    }
                    break;
                case TestTypes.ChiProbability:
                    {
                        if (Math.Abs(Res1.ChiProbability - 0.5) > Math.Abs(Res2.ChiProbability - 0.5))
                            winner = _Opponent;
                    }
                    break;
                case TestTypes.ChiSquare:
                    {
                        if (Math.Abs(Res1.ChiSquare - 256.0) > Math.Abs(Res2.ChiSquare - 256.0))
                            winner = _Opponent;
                    }
                    break;
                case TestTypes.Mean:
                    {
                        if (Math.Abs(MEAN - Res1.Mean) > Math.Abs(MEAN - Res2.Mean))
                            winner = _Opponent;
                    }
                    break;
                case TestTypes.MonteCarloErrorPct:
                    {
                        if (Math.Abs(Res1.MonteCarloErrorPct) > Math.Abs(Res2.MonteCarloErrorPct))
                            winner = _Opponent;
                    }
                    break;
                case TestTypes.MonteCarloPiCalc:
                    {
                        if (Math.Abs(PI - Res1.MonteCarloPiCalc) > Math.Abs(PI - Res2.MonteCarloPiCalc))
                            winner = _Opponent;
                    }
                    break;
                case TestTypes.SerialCorrelation:
                    {
                        if (Math.Abs(Res1.SerialCorrelation) > Math.Abs(Res2.SerialCorrelation))
                            winner = _Opponent;
                    }
                    break;

            }
            return winner;
        }

        private bool Equal(byte[] Data1, byte[] Data2)
        {
            return Data1.SequenceEqual(Data2);
        }

        private byte[] GetSeed48()
        {
            byte[] data = new byte[48];
            Buffer.BlockCopy(CSPRNG.GetSeed64(), 0, data, 0, 48);

            return data;
        }

        private void TimerStart()
        {
            // start
            _runTimer.Reset();
            _runTimer.Start();
        }

        private double TimerStop()
        {
            // get results and reset
            _runTimer.Stop();
            return _runTimer.Elapsed.Milliseconds;
        }
        #endregion
    }
}
