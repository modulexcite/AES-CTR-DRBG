﻿using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Windows.Forms;
using System.Diagnostics;

namespace Drbg_Test
{
    public partial class Form1 : Form
    {
        #region Enums
        private enum ApiTypes
        {
            A,
            R,
        }

        private enum TestTypes : int
        {
            Entropy = 0,
            ChiSquare,
            ChiProbability,
            Mean,
            MonteCarloErrorPct,
            MonteCarloPiCalc,
            SerialCorrelation,
        }
        #endregion

        #region Constants
        // output random to file path
        private const string RANDOMOUT_PATH = @"C:\Tests\random.bin";
        // results file name
        private const string RESULTS_NAME = "results.txt";
        // number of random sample pairs to test
        private const int TEST_ITERATIONS = 100;
        // size of random chunks (10 kib)
        private const int CHUNK_SIZE = 10240;
        // size of random sample (1 mib)
        private const int SAMPLE_SIZE = 1024000;
        #endregion

        #region Fields
        private string _dlgPath = string.Empty;
        StreamWriter _dataWriter;
        #endregion

        #region Constructor
        public Form1()
        {
            InitializeComponent();
            btnTestAesCtr.Enabled = false;
            txtOutput.Text = "[Select a Destination Folder]";

            // test instance equality (throws on fail)
            CompareEqual();
            // test methods (throws on exception, output to debug window)
            TestOutputs();
            // test speed between algorithms (output to debug window)
            CompareSpeed(1024000);
            // unrem to write aesctr random to file
            //Write(GetRandom2(10240000), RANDOMOUT_PATH);
        }
        #endregion

        #region Controls
        private void OnTestClick(object sender, EventArgs e)
        {
            if (!Directory.Exists(Path.GetDirectoryName(_dlgPath))) return;

            using (_dataWriter = File.AppendText(_dlgPath))
            {
                pbStatus.Maximum = TEST_ITERATIONS;
                pbStatus.Value = 0;
                lblStatus.Text = "Processing..";
                lblStatus.Update();
                btnTestAesCtr.Enabled = false;
                grpBox.Enabled = false;

                // run the compare
                CompareApi(TEST_ITERATIONS, _dlgPath);

                grpBox.Enabled = true;
                lblStatus.Text = "Completed!";
                pbStatus.Value = TEST_ITERATIONS;/**/
            }
        }

        private void OnDialogClick(object sender, EventArgs e)
        {
            btnTestAesCtr.Enabled = false;
            txtOutput.Text = "[Select a Destination Folder]";
            pbStatus.Value = 0;

            using (FolderBrowserDialog fbDiag = new FolderBrowserDialog())
            {
                fbDiag.Description = "Select a Folder";

                if (fbDiag.ShowDialog() == DialogResult.OK)
                {
                    if (Directory.Exists(fbDiag.SelectedPath))
                        _dlgPath = Path.Combine(fbDiag.SelectedPath, RESULTS_NAME);
                    if (File.Exists(_dlgPath))
                        File.Delete(_dlgPath);

                    txtOutput.Text = _dlgPath;
                    btnTestAesCtr.Enabled = true;
                }
            }
        }

        private void OnCheckChanged(object sender, EventArgs e)
        {
            if (File.Exists(txtOutput.Text))
                File.Delete(txtOutput.Text);
            if (Directory.Exists(Path.GetDirectoryName(txtOutput.Text)))
                btnTestAesCtr.Enabled = true;
        }
        #endregion

        #region Tests
        private void CompareApi(int Iterations, string Path)
        {
            int percentA = 0;
            int percentR = 0;
            double entropyAvgA = 0;
            double entropyAvgR = 0;
            double chiProbA = 0;
            double chiProbR = 0;
            double chiSquareA = 0;
            double chiSquareR = 0;
            double montePiA = 0;
            double montePiR = 0;
            double monteErrA = 0;
            double monteErrR = 0;
            double meanA = 0;
            double meanR = 0;
            double serA = 0;
            double serR = 0;
            int chiProbWon = 0;
            int chiSquareWon = 0;
            int meanWon = 0;
            int monteErrWon = 0;
            int montePiWon = 0;
            int serCorWon = 0;
            ApiTypes api = ApiTypes.A;
            EntResult res1;
            EntResult res2;

            for (int i = 0; i < Iterations; i++)
            {
                Ent ent1 = new Ent();
                Ent ent2 = new Ent();

                if (rdRotating.Checked)
                    res1 = ent1.Calculate(GetRandomRotating(SAMPLE_SIZE));
                else if (rdOscillating.Checked)
                    res1 = ent1.Calculate(GetRandomOscillating(SAMPLE_SIZE));
                else
                    res1 = ent1.Calculate(GetRandomAutoSeed(SAMPLE_SIZE));

                if (rdAes800.Checked)
                    res2 = ent2.Calculate(GetAes800Drbg(SAMPLE_SIZE));
                else
                    res2 = ent2.Calculate(GetRNGRandom(SAMPLE_SIZE));

                ApiTypes bestPerc = EntCompare(res1, res2, TestTypes.Entropy);

                if (bestPerc == ApiTypes.A)
                    percentA++;
                else
                    percentR++;

                chiProbA += res1.ChiProbability;
                chiProbR += res2.ChiProbability;
                chiSquareA += res1.ChiSquare;
                chiSquareR += res2.ChiSquare;
                entropyAvgA += res1.Entropy;
                entropyAvgR += res2.Entropy;
                monteErrA += res1.MonteCarloErrorPct;
                monteErrR += res2.MonteCarloErrorPct;
                montePiA += res1.MonteCarloPiCalc;
                montePiR += res2.MonteCarloPiCalc;
                meanA += res1.Mean;
                meanR += res2.Mean;
                serA += res1.SerialCorrelation;
                serR += res2.SerialCorrelation;

                // flag the test winner (A or R)
                Append("Entropy Alg:" + bestPerc.ToString() + " AesCtr:" + res1.Entropy.ToString() + " RngApi: " + res2.Entropy.ToString(), Path);

                api = EntCompare(res1, res2, TestTypes.ChiProbability);
                if (api == ApiTypes.A) chiProbWon++;
                Append("ChiProbability: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.ChiSquare);
                if (api == ApiTypes.A) chiSquareWon++;
                Append("ChiSquare: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.Mean);
                if (api == ApiTypes.A) meanWon++;
                Append("Mean: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.MonteCarloErrorPct);
                if (api == ApiTypes.A) monteErrWon++;
                Append("MonteCarloErrorPct: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.MonteCarloPiCalc);
                if (api == ApiTypes.A) montePiWon++;
                Append("MonteCarloPiCalc: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.SerialCorrelation);
                if (api == ApiTypes.A) serCorWon++;
                Append("SerialCorrelation: " + api.ToString(), Path);
                Append(" ", Path);

                // Aes scores
                Append("AesCtr", Path);
                Append("ChiProbability: " + res1.ChiProbability.ToString(), Path);
                Append("ChiSquare: " + res1.ChiSquare.ToString(), Path);
                Append("Mean: " + res1.Mean.ToString(), Path);
                Append("MonteCarloErrorPct: " + res1.MonteCarloErrorPct.ToString(), Path);
                Append("MonteCarloPiCalc: " + res1.MonteCarloPiCalc.ToString(), Path);
                Append("SerialCorrelation: " + res1.SerialCorrelation.ToString(), Path);
                Append(" ", Path);
                // rng scores
                Append("RngApi", Path);
                Append("ChiProbability: " + res2.ChiProbability.ToString(), Path);
                Append("ChiSquare: " + res2.ChiSquare.ToString(), Path);
                Append("Mean: " + res2.Mean.ToString(), Path);
                Append("MonteCarloErrorPct: " + res2.MonteCarloErrorPct.ToString(), Path);
                Append("MonteCarloPiCalc: " + res2.MonteCarloPiCalc.ToString(), Path);
                Append("SerialCorrelation: " + res2.SerialCorrelation.ToString(), Path);
                Append("#######################################################", Path);
                Append(" ", Path);

                pbStatus.Value = i;
            }

            // get the averages
            int sumA = chiProbWon + chiSquareWon + meanWon + monteErrWon + montePiWon + serCorWon;
            int sumR = (Iterations * 6) - sumA;

            Append("Best Entropy: Aes: " + percentA.ToString() + " Rng: " + percentR.ToString(), Path);
            Append("Entropy Avg: Aes: " + (entropyAvgA / Iterations).ToString() + " Rng: " + (entropyAvgR / Iterations).ToString(), Path);
            Append("Total Tests Score: Aes: " + sumA.ToString() + " Rng: " + sumR.ToString(), Path);
            Append("ChiProbability Score: Aes: " + chiProbWon.ToString() + " Rng: " + (Iterations - chiProbWon).ToString(), Path);
            Append("ChiProbability Avg: Aes: " + (chiProbA / Iterations).ToString() + " Rng: " + (chiProbR / Iterations).ToString(), Path);
            Append("ChiSquare Score: Aes: " + chiSquareWon.ToString() + " Rng: " + (Iterations - chiSquareWon).ToString(), Path);
            Append("ChiSquare Avg: Aes: " + (chiSquareA / Iterations).ToString() + " Rng: " + (chiSquareR / Iterations).ToString(), Path);
            Append("MonteCarlo Error Score: Aes: " + monteErrWon.ToString() + " Rng: " + (Iterations - monteErrWon).ToString(), Path);
            Append("MonteCarlo Error Avg: Aes: " + (monteErrA / Iterations).ToString() + " Rng: " + (monteErrR / Iterations).ToString(), Path);
            Append("MonteCarlo Pi Score: Aes: " + montePiWon.ToString() + " Rng: " + (Iterations - montePiWon).ToString(), Path);
            Append("MonteCarlo Pi Avg: Aes: " + (montePiA / Iterations).ToString() + " Rng: " + (montePiR / Iterations).ToString(), Path);
            Append("Mean Score: Aes: " + meanWon.ToString() + " Rng: " + (Iterations - meanWon).ToString(), Path);
            Append("Mean Avg: Aes: " + (meanA / Iterations).ToString() + " Rng: " + (meanR / Iterations).ToString(), Path);
            Append("Serial Correlation Score: Aes: " + serCorWon.ToString() + " Rng: " + (Iterations - serCorWon).ToString(), Path);
            Append("Serial Correlation Avg: Aes: " + (serA / Iterations).ToString() + " Rng: " + (serR / Iterations).ToString(), Path);
        }

        private void CompareEqual()
        {
            byte[] data = new byte[1024000];
            byte[] data2 = new byte[1024000];
            byte[] seed = GetSeed64();

            using (AesCtr ctr = new AesCtr())
                data = ctr.Generate(seed, 1024000);
            using (AesCtr ctr = new AesCtr())
                data2 = ctr.Generate(seed, 1024000);

            if (!Equal(data, data2))
                throw new Exception("Arrays are not equal!");
        }

        private void CompareSpeed(int Size)
        {
            byte[] data = new byte[Size];
            byte[] seed512 = GetSeed64();
            byte[] seed384 = GetSeed48();
            string state = " created " + Size.ToString() +  " bytes in ";

            // start
            Stopwatch testTimer = new Stopwatch();
            testTimer.Start();

            // AesCtr
            using (AesCtr random = new AesCtr())
                data = random.Generate(seed512, Size);

            // get results and reset
            testTimer.Stop();
            TimeSpan elapsed = testTimer.Elapsed;
            Console.WriteLine("AesCtr" + state + elapsed.ToString(@"m\:ss\.ff") + " seconds");
            data = new byte[Size];
            testTimer.Reset();
            testTimer.Start();

            // RNGCryptoServiceProvider
            using (RNGCryptoServiceProvider random = new RNGCryptoServiceProvider())
                random.GetBytes(data);

            // get results and reset
            testTimer.Stop();
            elapsed = testTimer.Elapsed;
            Console.WriteLine("RNGCryptoServiceProvider" + state + elapsed.ToString(@"m\:ss\.ff") + " seconds");
            data = new byte[Size];
            testTimer.Reset();
            testTimer.Start();

            // Aes800Drbg
            Aes800Drbg ctr = new Aes800Drbg(GetSeed48());
            ctr.Generate(data);
            testTimer.Stop();
            elapsed = testTimer.Elapsed;
            Console.WriteLine("Aes800Drbg" + state + elapsed.ToString(@"m\:ss\.ff") + " seconds");
        }

        private void TestOutputs()
        {
            try
            {
                using (AesCtr random = new AesCtr())
                {
                    Console.WriteLine("Double: " + random.NextDouble().ToString());
                    Console.WriteLine("Float: " + random.NextFloat().ToString());
                    Console.WriteLine("Int16: " + random.NextInt16().ToString());
                    Console.WriteLine("UInt16: " + random.NextUInt16().ToString());
                    Console.WriteLine("Int32: " + random.NextInt32().ToString());
                    Console.WriteLine("UInt32: " + random.NextUInt32().ToString());
                    Console.WriteLine("Int64: " + random.NextInt64().ToString());
                    Console.WriteLine("UInt64: " + random.NextUInt64().ToString());

                    Int16[] num16 = new Int16[8];
                    random.GetInt16s(num16);
                    Console.WriteLine("UInt16 array: " + string.Join(",", num16));

                    Int32[] num32 = new Int32[8];
                    random.GetInt32s(num32);
                    Console.WriteLine("UInt32 array: " + string.Join(",", num32));

                    Int64[] num64 = new Int64[8];
                    random.GetInt64s(num64);
                    Console.WriteLine("UInt64 array: " + string.Join(",", num64));

                    byte[] btA = new byte[8];
                    random.GetBytes(btA);
                    Console.WriteLine("byte array: " + string.Join(",", btA));

                    char[] chA = new char[8];
                    random.GetChars(chA);
                    Console.WriteLine("char array: " + string.Join(",", chA));
                }
            }
            catch (Exception ex)
            {
                throw new Exception("TestOutputs() has failed!");
            }
        }
        #endregion

        #region Algorithms
        /// <summary>
        /// Get random using the Aes800Drbg algorithm
        /// </summary>
        private byte[] GetAes800Drbg(int Size)
        {
            byte[] output = new byte[Size];
            Aes800Drbg ctr;

            for (int i = 0; i < Size; i += CHUNK_SIZE)
            {
                byte[] data = new byte[CHUNK_SIZE];
                byte[] seed = GetSeed64();

                ctr = new Aes800Drbg(GetSeed48());
                ctr.Generate(data);

                Buffer.BlockCopy(data, 0, output, i, CHUNK_SIZE);
            }

            return output;
        }

        /// <summary>
        /// Get random using AesCtr in auto seeding mode
        /// </summary>
        private byte[] GetRandomAutoSeed(int Size)
        {
            byte[] output = new byte[Size];

            for (int i = 0; i < Size; i += CHUNK_SIZE)
            {
                byte[] data = new byte[CHUNK_SIZE];

                using (AesCtr random = new AesCtr())
                    random.Generate(CHUNK_SIZE);

                Buffer.BlockCopy(data, 0, output, i, CHUNK_SIZE);
            }

            return output;
        }

        /// <summary>
        /// Get random using AesCtr in key oscillating mode
        /// </summary>
        private byte[] GetRandomOscillating(int Size)
        {
            byte[] output = new byte[Size];

            for (int i = 0; i < Size; i += CHUNK_SIZE)
            {
                byte[] data = new byte[CHUNK_SIZE];
                byte[] seed = GetSeed64();

                using (AesCtr random = new AesCtr())
                    random.GenerateOsc(seed, CHUNK_SIZE);

                Buffer.BlockCopy(data, 0, output, i, CHUNK_SIZE);
            }

            return output;
        }

        /// <summary>
        /// Get random using AesCtr in key rotation mode
        /// </summary>
        private byte[] GetRandomRotating(int Size)
        {
            byte[] output = new byte[Size];

            for (int i = 0; i < Size; i += CHUNK_SIZE)
            {
                byte[] data = new byte[CHUNK_SIZE];
                byte[] seed = GetSeed64();

                using (AesCtr random = new AesCtr())
                    random.Generate(seed, CHUNK_SIZE);

                Buffer.BlockCopy(data, 0, output, i, CHUNK_SIZE);
            }

            return output;
        }

        /// <summary>
        /// Uses the native RNGCryptoServiceProvider algorithm
        /// </summary>
        /// <param name="Size">Size of return in bytes</param>
        /// <returns>Random byte array [byte]]</returns>
        private byte[] GetRNGRandom(int Size)
        {
            byte[] output = new byte[Size];

            for (int i = 0; i < Size; i += CHUNK_SIZE)
            {
                byte[] data = new byte[CHUNK_SIZE];

                using (RNGCryptoServiceProvider random = new RNGCryptoServiceProvider())
                    random.GetBytes(data);

                Buffer.BlockCopy(data, 0, output, i, CHUNK_SIZE);
            }

            return output;
        }
        #endregion
        
        #region Helpers
        private void Append(string Data, string Path)
        {
            _dataWriter.WriteLine(Data);
        }

        private void Write(byte[] Data, string Path)
        {
            using (BinaryWriter writer = new BinaryWriter(File.Open(Path, FileMode.Create)))
                writer.Write(Data);
        }

        private ApiTypes EntCompare(EntResult Res1, EntResult Res2, TestTypes TestType = TestTypes.Entropy)
        {
            const double MEAN = 127.5;
            const double PI = 3.1415926535;

            ApiTypes winner = ApiTypes.A;

            switch (TestType)
            {
                case TestTypes.Entropy:
                    {
                        if (Res2.Entropy > Res1.Entropy)
                            winner = ApiTypes.R;
                    }
                    break;
                case TestTypes.ChiProbability:
                    {
                        if (Math.Abs(Res1.ChiProbability - 0.5) > Math.Abs(Res2.ChiProbability - 0.5))
                            winner = ApiTypes.R;
                    }
                    break;
                case TestTypes.ChiSquare:
                    {
                        if (Math.Abs(Res1.ChiSquare - 256.0) > Math.Abs(Res2.ChiSquare - 256.0))
                            winner = ApiTypes.R;
                    }
                    break;
                case TestTypes.Mean:
                    {
                        if (Math.Abs(MEAN - Res1.Mean) > Math.Abs(MEAN - Res2.Mean))
                            winner = ApiTypes.R;
                    }
                    break;
                case TestTypes.MonteCarloErrorPct:
                    {
                        if (Math.Abs(Res1.MonteCarloErrorPct) > Math.Abs(Res2.MonteCarloErrorPct))
                            winner = ApiTypes.R;
                    }
                    break;
                case TestTypes.MonteCarloPiCalc:
                    {
                        if (Math.Abs(PI - Res1.MonteCarloPiCalc) > Math.Abs(PI - Res2.MonteCarloPiCalc))
                            winner = ApiTypes.R;
                    }
                    break;
                case TestTypes.SerialCorrelation:
                    {
                        if (Math.Abs(Res1.SerialCorrelation) > Math.Abs(Res2.SerialCorrelation))
                            winner = ApiTypes.R;
                    }
                    break;

            }
            return winner;
        }

        private bool Equal(byte[] Data1, byte[] Data2)
        {
            return Data1.SequenceEqual(Data2);
        }

        private byte[] GetSeed64()
        {
            using (RNGCryptoServiceProvider random = new RNGCryptoServiceProvider())
            {
                byte[] data = new byte[128];
                byte[] data2 = new byte[128];
                byte[] result = new byte[64];

                random.GetBytes(data);
                random.GetBytes(data2);

                // entropy extractor
                using (SHA256 shaHash = SHA256Managed.Create())
                {
                    Buffer.BlockCopy(shaHash.ComputeHash(data), 0, result, 0, 32);
                    Buffer.BlockCopy(shaHash.ComputeHash(data2), 0, result, 32, 32);
                    return result;
                }
            }
        }

        private byte[] GetSeed48()
        {
            byte[] data = GetSeed64();
            byte[] data2 = new byte[48];
            Buffer.BlockCopy(data, 0, data2, 0, 32);
            Buffer.BlockCopy(data, 0, data2, 32, 16);
            return data2;
        }
        #endregion
    }
}
