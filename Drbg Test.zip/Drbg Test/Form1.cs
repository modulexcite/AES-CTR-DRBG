﻿using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Windows.Forms;
using System.Diagnostics;

namespace Drbg_Test
{
    public partial class Form1 : Form
    {
        #region Enums
        private enum ApiTypes
        {
            A,
            R,
        }

        private enum TestTypes : int
        {
            Entropy = 0,
            ChiSquare,
            ChiProbability,
            Mean,
            MonteCarloErrorPct,
            MonteCarloPiCalc,
            SerialCorrelation,
        }
        #endregion

        #region Constants
        // output random to file path
        private const string RANDOMOUT_PATH = @"C:\Tests\random.bin";
        // results file name
        private const string RESULTS_NAME = "results.txt";
        #endregion

        #region Fields
        private int Iterations = 1000;
        private int SampleSize = 102400;
        private string _dlgPath = string.Empty;
        private StreamWriter _dataWriter;
        private RNGCryptoServiceProvider _rngRandom = new RNGCryptoServiceProvider();
        #endregion

        #region Constructor
        public Form1()
        {
            InitializeComponent();
            btnTestAesCtr.Enabled = false;
            txtOutput.Text = "[Select a Destination Folder]";

            // test instance equality (throws on fail)
            CompareEqual();
            // test methods (throws on exception, output to debug window)
            TestOutputs();
            // test speed between algorithms (output to debug window)
            CompareSpeed(1024000);
            // unrem to write 10Mib AesCtr autoseed mode
            //Write(GetRandomAutoSeed(102400000), RANDOMOUT_PATH);
            // unrem to write 10Mib AesCtr oscillating mode
            //Write(GetRandomOscillating(102400000), RANDOMOUT_PATH);
            // unrem to write 10Mib AesCtr rotating mode
            //Write(GetRandomRotating(102400000), RANDOMOUT_PATH);
            // unrem to write 10Mib Aes800Drbg
            //Write(GetAes800Drbg(102400000), RANDOMOUT_PATH);
            // unrem to write 10Mib RNGCryptoServiceProvider
            //Write(GetRNGRandom(102400000), RANDOMOUT_PATH);
        }
        #endregion

        #region Controls
        private void OnCheckChanged(object sender, EventArgs e)
        {
            if (File.Exists(txtOutput.Text))
                File.Delete(txtOutput.Text);
            if (Directory.Exists(Path.GetDirectoryName(txtOutput.Text)))
                btnTestAesCtr.Enabled = true;
        }

        private void OnDialogClick(object sender, EventArgs e)
        {
            btnTestAesCtr.Enabled = false;
            txtOutput.Text = "[Select a Destination Folder]";
            pbStatus.Value = 0;

            using (FolderBrowserDialog fbDiag = new FolderBrowserDialog())
            {
                fbDiag.Description = "Select a Folder";

                if (fbDiag.ShowDialog() == DialogResult.OK)
                {
                    if (Directory.Exists(fbDiag.SelectedPath))
                        _dlgPath = Path.Combine(fbDiag.SelectedPath, RESULTS_NAME);
                    if (File.Exists(_dlgPath))
                        File.Delete(_dlgPath);

                    txtOutput.Text = _dlgPath;
                    btnTestAesCtr.Enabled = true;
                }
            }
        }

        private void OnSelectedValueChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;
            if (cb == null) return;
            if (cb.SelectedItem == null) return;
            
            if (cb.Name == "cbTestIterations")
            {
                int sampleCount = 0;
                int.TryParse(cb.SelectedItem.ToString(), out sampleCount);
                if (sampleCount < 1) return;
                this.Iterations = sampleCount;
            }
            else
            {
                int sampleSize = 0;
                int.TryParse(cb.SelectedItem.ToString(), out sampleSize);
                if (sampleSize < 1) return;
                this.SampleSize = sampleSize * 1024;
            }

            int sum = this.Iterations * this.SampleSize;

            if (sum > 102400000)
                MessageBox.Show("That is " + sum.ToString() + "Kib.. This could take a long time to calculate..", "AesCtr", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void OnTestClick(object sender, EventArgs e)
        {
            if (!Directory.Exists(Path.GetDirectoryName(_dlgPath))) return;

            if (this.Iterations < 1 || this.SampleSize < 1) return;

            using (_dataWriter = File.AppendText(_dlgPath))
            {
                // set up the controls
                pbStatus.Maximum = Iterations;
                pbStatus.Value = 0;
                lblStatus.Text = "Processing 2 * " + (this.Iterations * this.SampleSize).ToString() + " bytes..";
                lblStatus.Update();
                btnTestAesCtr.Enabled = false;
                grpBox.Enabled = false;
                grpTestCount.Enabled = false;

                // run the compare
                CompareApi(Iterations, _dlgPath, false);

                // enable and notify
                grpBox.Enabled = true;
                grpTestCount.Enabled = true;
                lblStatus.Text = "Completed!";
                pbStatus.Value = Iterations;
            }
        }
        #endregion

        #region Tests
        private void CompareApi(int Iterations, string Path, bool SummaryOnly = false)
        {
            int percentA = 0;
            int percentR = 0;
            double entropyAvgA = 0;
            double entropyAvgR = 0;
            double chiProbA = 0;
            double chiProbR = 0;
            double chiSquareA = 0;
            double chiSquareR = 0;
            double montePiA = 0;
            double montePiR = 0;
            double monteErrA = 0;
            double monteErrR = 0;
            double meanA = 0;
            double meanR = 0;
            double serA = 0;
            double serR = 0;
            int chiProbWon = 0;
            int chiSquareWon = 0;
            int meanWon = 0;
            int monteErrWon = 0;
            int montePiWon = 0;
            int serCorWon = 0;
            ApiTypes api = ApiTypes.A;
            EntResult res1;
            EntResult res2;
            Ent ent1 = new Ent();
            Ent ent2 = new Ent();

            for (int i = 0; i < Iterations; i++)
            {
                if (rdRotating.Checked)
                    res1 = ent1.Calculate(GetRandomRotating(SampleSize));
                else if (rdOscillating.Checked)
                    res1 = ent1.Calculate(GetRandomOscillating(SampleSize));
                else
                    res1 = ent1.Calculate(GetRandomAutoSeed(SampleSize));

                if (rdAes800.Checked)
                    res2 = ent2.Calculate(GetAes800Drbg(SampleSize));
                else
                    res2 = ent2.Calculate(GetRNGRandom(SampleSize));

                ApiTypes bestPerc = EntCompare(res1, res2, TestTypes.Entropy);

                if (bestPerc == ApiTypes.A)
                    percentA++;
                else
                    percentR++;

                chiProbA += res1.ChiProbability;
                chiProbR += res2.ChiProbability;
                chiSquareA += res1.ChiSquare;
                chiSquareR += res2.ChiSquare;
                entropyAvgA += res1.Entropy;
                entropyAvgR += res2.Entropy;
                monteErrA += res1.MonteCarloErrorPct;
                monteErrR += res2.MonteCarloErrorPct;
                montePiA += res1.MonteCarloPiCalc;
                montePiR += res2.MonteCarloPiCalc;
                meanA += res1.Mean;
                meanR += res2.Mean;
                serA += res1.SerialCorrelation;
                serR += res2.SerialCorrelation;

                // flag the test winner (A or R)
                if (!SummaryOnly) Append("Entropy Alg:" + bestPerc.ToString() + " AesCtr:" + res1.Entropy.ToString() + " RngApi: " + res2.Entropy.ToString(), Path);

                api = EntCompare(res1, res2, TestTypes.ChiProbability);
                if (api == ApiTypes.A) chiProbWon++;
                if (!SummaryOnly) Append("ChiProbability: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.ChiSquare);
                if (api == ApiTypes.A) chiSquareWon++;
                if (!SummaryOnly) Append("ChiSquare: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.Mean);
                if (api == ApiTypes.A) meanWon++;
                if (!SummaryOnly) Append("Mean: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.MonteCarloErrorPct);
                if (api == ApiTypes.A) monteErrWon++;
                if (!SummaryOnly) Append("MonteCarloErrorPct: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.MonteCarloPiCalc);
                if (api == ApiTypes.A) montePiWon++;
                if (!SummaryOnly) Append("MonteCarloPiCalc: " + api.ToString(), Path);
                api = EntCompare(res1, res2, TestTypes.SerialCorrelation);
                if (api == ApiTypes.A) serCorWon++;
                if (!SummaryOnly) Append("SerialCorrelation: " + api.ToString(), Path);
                if (!SummaryOnly) Append(" ", Path);

                if (!SummaryOnly)
                {
                    // Aes scores
                    Append("AesCtr", Path);
                    Append("ChiProbability: " + res1.ChiProbability.ToString(), Path);
                    Append("ChiSquare: " + res1.ChiSquare.ToString(), Path);
                    Append("Mean: " + res1.Mean.ToString(), Path);
                    Append("MonteCarloErrorPct: " + res1.MonteCarloErrorPct.ToString(), Path);
                    Append("MonteCarloPiCalc: " + res1.MonteCarloPiCalc.ToString(), Path);
                    Append("SerialCorrelation: " + res1.SerialCorrelation.ToString(), Path);
                    Append(" ", Path);
                    // rng scores
                    if (!SummaryOnly) Append("RngApi", Path);
                    Append("ChiProbability: " + res2.ChiProbability.ToString(), Path);
                    Append("ChiSquare: " + res2.ChiSquare.ToString(), Path);
                    Append("Mean: " + res2.Mean.ToString(), Path);
                    Append("MonteCarloErrorPct: " + res2.MonteCarloErrorPct.ToString(), Path);
                    Append("MonteCarloPiCalc: " + res2.MonteCarloPiCalc.ToString(), Path);
                    Append("SerialCorrelation: " + res2.SerialCorrelation.ToString(), Path);
                    Append("#######################################################", Path);
                    Append(" ", Path);
                }
                pbStatus.Value = i;
                ent1.Reset();
                ent2.Reset();
            }

            // get the averages
            int sumA = chiProbWon + chiSquareWon + meanWon + monteErrWon + montePiWon + serCorWon;
            int sumR = (Iterations * 6) - sumA;

            Append("Best Overall Entropy: Aes: " + percentA.ToString() + " Rng: " + percentR.ToString(), Path);
            Append(" ", Path);
            Append("Entropy Avg: Aes: " + (entropyAvgA / Iterations).ToString() + " Rng: " + (entropyAvgR / Iterations).ToString(), Path);
            Append(" ", Path);
            Append("Total Wins of Tests Scored: Aes: " + sumA.ToString() + " Rng: " + sumR.ToString(), Path);
            Append(" ", Path);
            Append("ChiProbability Score: Aes: " + chiProbWon.ToString() + " Rng: " + (Iterations - chiProbWon).ToString(), Path);
            Append("ChiProbability Avg: Aes: " + (chiProbA / Iterations).ToString() + " Rng: " + (chiProbR / Iterations).ToString(), Path);
            Append(" ", Path);
            Append("ChiSquare Score: Aes: " + chiSquareWon.ToString() + " Rng: " + (Iterations - chiSquareWon).ToString(), Path);
            Append("ChiSquare Avg: Aes: " + (chiSquareA / Iterations).ToString() + " Rng: " + (chiSquareR / Iterations).ToString(), Path);
            Append(" ", Path);
            Append("MonteCarlo Error Score: Aes: " + monteErrWon.ToString() + " Rng: " + (Iterations - monteErrWon).ToString(), Path);
            Append("MonteCarlo Error Avg: Aes: " + (monteErrA / Iterations).ToString() + " Rng: " + (monteErrR / Iterations).ToString(), Path);
            Append(" ", Path);
            Append("MonteCarlo Pi Score: Aes: " + montePiWon.ToString() + " Rng: " + (Iterations - montePiWon).ToString(), Path);
            Append("MonteCarlo Pi Avg: Aes: " + (montePiA / Iterations).ToString() + " Rng: " + (montePiR / Iterations).ToString(), Path);
            Append(" ", Path);
            Append("Mean Score: Aes: " + meanWon.ToString() + " Rng: " + (Iterations - meanWon).ToString(), Path);
            Append("Mean Avg: Aes: " + (meanA / Iterations).ToString() + " Rng: " + (meanR / Iterations).ToString(), Path);
            Append(" ", Path);
            Append("Serial Correlation Score: Aes: " + serCorWon.ToString() + " Rng: " + (Iterations - serCorWon).ToString(), Path);
            Append("Serial Correlation Avg: Aes: " + (serA / Iterations).ToString() + " Rng: " + (serR / Iterations).ToString(), Path);

            ent1.Dispose();
            ent2.Dispose();
        }

        private void CompareEqual()
        {
            byte[] data = new byte[1024000];
            byte[] data2 = new byte[1024000];
            byte[] seed = GetSeed64();

            using (AesCtr ctr = new AesCtr())
                data = ctr.Generate(seed, 1024000);
            using (AesCtr ctr = new AesCtr())
                data2 = ctr.Generate(seed, 1024000);

            if (Equal(data, data2))
                Console.WriteLine("Equality Test: Passed!");
            else
                Console.WriteLine("Equality Test: Failed!");
        }

        private void CompareSpeed(int Size)
        {
            byte[] data = new byte[Size];
            byte[] seed512 = GetSeed64();
            byte[] seed384 = GetSeed48();
            string state = " created " + Size.ToString() +  " bytes in ";

            // start
            Stopwatch testTimer = new Stopwatch();
            testTimer.Start();

            // AesCtr
            using (AesCtr random = new AesCtr())
                data = random.Generate(seed512, Size);

            // get results and reset
            testTimer.Stop();
            TimeSpan elapsed = testTimer.Elapsed;
            Console.WriteLine("AesCtr" + state + elapsed.ToString(@"m\:ss\.ff") + " seconds");
            data = new byte[Size];
            testTimer.Reset();
            testTimer.Start();

            // RNGCryptoServiceProvider
            _rngRandom.GetBytes(data);

            // get results and reset
            testTimer.Stop();
            elapsed = testTimer.Elapsed;
            Console.WriteLine("RNGCryptoServiceProvider" + state + elapsed.ToString(@"m\:ss\.ff") + " seconds");
            data = new byte[Size];
            testTimer.Reset();
            testTimer.Start();

            // Aes800Drbg
            Aes800Drbg ctr = new Aes800Drbg(GetSeed48());
            ctr.Generate(data);
            testTimer.Stop();
            elapsed = testTimer.Elapsed;
            Console.WriteLine("Aes800Drbg" + state + elapsed.ToString(@"m\:ss\.ff") + " seconds");
        }

        private void TestOutputs()
        {
            try
            {
                Console.WriteLine("Testing CPRNG..");
                Console.WriteLine("Double: " + CSPRNG.NextDouble().ToString());
                Console.WriteLine("Float: " + CSPRNG.NextFloat().ToString());
                Console.WriteLine("Int16: " + CSPRNG.NextInt16().ToString());
                Console.WriteLine("UInt16: " + CSPRNG.NextUInt16().ToString());
                Console.WriteLine("Int32: " + CSPRNG.NextInt32().ToString());
                Console.WriteLine("UInt32: " + CSPRNG.NextUInt32().ToString());
                Console.WriteLine("Int64: " + CSPRNG.NextInt64().ToString());
                Console.WriteLine("UInt64: " + CSPRNG.NextUInt64().ToString());

                Console.WriteLine("Testing AesCtr..");
                using (AesCtr random = new AesCtr())
                {
                    Int16[] num16 = new Int16[8];
                    random.GetInt16s(num16);
                    Console.WriteLine("Int16 array: " + string.Join(",", num16));

                    Int32[] num32 = new Int32[8];
                    random.GetInt32s(num32);
                    Console.WriteLine("Int32 array: " + string.Join(",", num32));

                    Int64[] num64 = new Int64[8];
                    random.GetInt64s(num64);
                    Console.WriteLine("Int64 array: " + string.Join(",", num64));

                    byte[] btA = new byte[8];
                    random.GetBytes(btA);
                    Console.WriteLine("byte array: " + string.Join(",", btA));

                    char[] chA = new char[8];
                    random.GetChars(chA);
                    Console.WriteLine("char array: " + string.Join(",", chA));
                }
            }
            catch (Exception ex)
            {
                throw new Exception("TestOutputs() has failed!");
            }
        }
        #endregion

        #region Algorithms
        /// <summary>
        /// Get random using the Aes800Drbg algorithm
        /// </summary>
        private byte[] GetAes800Drbg(int Size)
        {
            byte[] data = new byte[Size];

            Aes800Drbg ctr = new Aes800Drbg(GetSeed48());
            ctr.Generate(data);

            return data;
        }

        /// <summary>
        /// Get random using AesCtr in auto seeding mode
        /// </summary>
        private byte[] GetRandomAutoSeed(int Size)
        {
            byte[] data = new byte[Size];

            using (AesCtr random = new AesCtr())
                data = random.Generate(Size);

            return data;
        }

        /// <summary>
        /// Get random using AesCtr in key oscillating mode
        /// </summary>
        private byte[] GetRandomOscillating(int Size)
        {
            byte[] data = new byte[Size];

            using (AesCtr random = new AesCtr())
                data = random.GenerateOsc(GetSeed64(), Size);

            return data;
        }

        /// <summary>
        /// Get random using AesCtr in key rotation mode
        /// </summary>
        private byte[] GetRandomRotating(int Size)
        {
            byte[] data = new byte[Size];

            using (AesCtr random = new AesCtr())
                data = random.Generate(GetSeed64(), Size);

            return data;
        }

        /// <summary>
        /// Uses the native RNGCryptoServiceProvider algorithm
        /// </summary>
        /// <param name="Size">Size of return in bytes</param>
        /// <returns>Random byte array [byte]]</returns>
        private byte[] GetRNGRandom(int Size)
        {
            byte[] data = new byte[Size];

            _rngRandom.GetBytes(data);

            return data;
        }
        #endregion
        
        #region Helpers
        private void Append(string Data, string Path)
        {
            _dataWriter.WriteLine(Data);
        }

        private void Write(byte[] Data, string Path)
        {
            using (BinaryWriter writer = new BinaryWriter(File.Open(Path, FileMode.Create)))
                writer.Write(Data);
        }

        private ApiTypes EntCompare(EntResult Res1, EntResult Res2, TestTypes TestType = TestTypes.Entropy)
        {
            const double MEAN = 127.5;
            const double PI = 3.1415926535;

            ApiTypes winner = ApiTypes.A;

            switch (TestType)
            {
                case TestTypes.Entropy:
                    {
                        if (Res2.Entropy > Res1.Entropy)
                            winner = ApiTypes.R;
                    }
                    break;
                case TestTypes.ChiProbability:
                    {
                        if (Math.Abs(Res1.ChiProbability - 0.5) > Math.Abs(Res2.ChiProbability - 0.5))
                            winner = ApiTypes.R;
                    }
                    break;
                case TestTypes.ChiSquare:
                    {
                        if (Math.Abs(Res1.ChiSquare - 256.0) > Math.Abs(Res2.ChiSquare - 256.0))
                            winner = ApiTypes.R;
                    }
                    break;
                case TestTypes.Mean:
                    {
                        if (Math.Abs(MEAN - Res1.Mean) > Math.Abs(MEAN - Res2.Mean))
                            winner = ApiTypes.R;
                    }
                    break;
                case TestTypes.MonteCarloErrorPct:
                    {
                        if (Math.Abs(Res1.MonteCarloErrorPct) > Math.Abs(Res2.MonteCarloErrorPct))
                            winner = ApiTypes.R;
                    }
                    break;
                case TestTypes.MonteCarloPiCalc:
                    {
                        if (Math.Abs(PI - Res1.MonteCarloPiCalc) > Math.Abs(PI - Res2.MonteCarloPiCalc))
                            winner = ApiTypes.R;
                    }
                    break;
                case TestTypes.SerialCorrelation:
                    {
                        if (Math.Abs(Res1.SerialCorrelation) > Math.Abs(Res2.SerialCorrelation))
                            winner = ApiTypes.R;
                    }
                    break;

            }
            return winner;
        }

        private bool Equal(byte[] Data1, byte[] Data2)
        {
            return Data1.SequenceEqual(Data2);
        }

        private byte[] GetSeed64()
        {
            byte[] data = new byte[128];
            byte[] data2 = new byte[128];
            byte[] result = new byte[64];

            _rngRandom.GetBytes(data);
            _rngRandom.GetBytes(data2);

            // entropy extractor
            using (SHA256 shaHash = SHA256Managed.Create())
            {
                Buffer.BlockCopy(shaHash.ComputeHash(data), 0, result, 0, 32);
                Buffer.BlockCopy(shaHash.ComputeHash(data2), 0, result, 32, 32);
                return result;
            }
        }

        /// <summary>
        /// Get a 64 byte/512 bit seed
        /// </summary>
        /// <returns>Random seed [byte[]]</returns>
        public byte[] GetSeed64Xs()
        {
            byte[] data1 = new byte[128];
            byte[] data2 = new byte[128];
            byte[] data3 = new byte[128];
            byte[] data4 = new byte[128];
            byte[] seed = new byte[64];

            // get the random seeds
            _rngRandom.GetBytes(data1);
            _rngRandom.GetBytes(data2);
            _rngRandom.GetBytes(data3);
            _rngRandom.GetBytes(data4);

            // xor buffer 1 and 3
            for (int j = 0; j < 128; j++)
                data1[j] ^= data3[j];

            // xor buffer 2 and 4
            for (int j = 0; j < 128; j++)
                data2[j] ^= data4[j];

            // copy through entropy extractor
            using (SHA256 shaHash = SHA256Managed.Create())
            {
                Buffer.BlockCopy(shaHash.ComputeHash(data1), 0, seed, 0, 32);
                Buffer.BlockCopy(shaHash.ComputeHash(data2), 0, seed, 32, 32);
            }

            return seed;
        }

        private byte[] GetSeed48()
        {
            byte[] data = GetSeed64();
            byte[] data2 = new byte[48];
            Buffer.BlockCopy(data, 0, data2, 0, 48);

            return data2;
        }
        #endregion
    }
}
