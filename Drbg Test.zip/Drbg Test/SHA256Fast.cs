﻿// Author:
// Matthew S. Ford (Matthew.S.Ford@Rose-Hulman.Edu)
//
// (C) 2001 
// Copyright (C) 2004, 2005 Novell, Inc (http://www.novell.com)
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

/// An SHA256 implementation..
/// Written based on implementations Mono: https://github.com/mono, and BouncyCastle: http://bouncycastle.org/
/// Many thanks to the authors of those great projects.. j.u.

using System;
using System.IO;

namespace Drbg_Test
{
    /// <summary>
    /// Implementation of the SHA256 algorithm
    /// </summary>
    internal class SHA256Fast : IDisposable
    {
        #region Constants
        private const int BLOCK_BYTES = 64;
        private const int DIGEST_LENGTH = 32;
        private const string DIGEST_NAME = "SHA-256";
        #endregion

        #region Fields
        private ulong _blockCount = 0;
        private bool _isDisposed = false;
        private uint[] _hashBuffer = new uint[8];
        private int _hashSize = 0;
        private byte[] _hashValue;
        private byte[] _processingBuffer = new byte[BLOCK_BYTES];
        private int _processingBufferCount = 0;
        #endregion

        #region Constructor
        /// <summary>
        /// SHA256 Constructor
        /// </summary>
        internal SHA256Fast()
        {
            Initialize();
        }

        ~SHA256Fast()
        {
            Dispose(false);
        }
        #endregion

        #region Public Properties
        /// <summary>
        /// Returns the Algorithm Name
        /// </summary>
        internal string AlgorithmName
        {
            get { return DIGEST_NAME; }
        }

        /// <summary>
        /// Internal block size
        /// </summary>
        internal int BlockSize
        {
            get { return BLOCK_BYTES; }
        }

        /// <summary>
        /// Returns Can transform multiple blocks (true)
        /// </summary>
        internal bool CanTransformMultipleBlocks
        {
            get { return true; }
        }

        /// <summary>
        /// Transform Can be reused (true)
        /// </summary>
        internal bool CanReuseTransform
        {
            get { return true; }
        }

        /// <summary>
        /// Returns digest ouput size
        /// </summary>
        internal int DigestSize
        {
            get { return DIGEST_LENGTH; }
        }

        /// <summary>
        /// Returns digest length
        /// </summary>
        internal int GetDigestSize
        {
            get { return _hashSize; }
        }

        /// <summary>
        /// Returns the hash value
        /// </summary>
        internal byte[] Hash
        {
            get { return _hashValue; }
        }

        /// <summary>
        /// Returns minimum input block count (*BlockSize bytes)
        /// </summary>
        internal virtual int InputBlockSize
        {
            get { return 1; }
        }

        /// <summary>
        /// returns minimum output block count (*BlockSize bytes)
        /// </summary>
        internal virtual int OutputBlockSize
        {
            get { return 1; }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Disposes the class and resets internal state
        /// </summary>
        internal void Clear()
        {
            Dispose(true);
        }

        /// <summary>
        /// Computes the hash value of the input buffer
        /// </summary>
        /// <param name="InputBuffer">Input buffer, minimum input is BlockSize [64]</param>
        /// <returns>Returns the hash value [byte array]</returns>
        internal byte[] ComputeHash(byte[] InputBuffer)
        {
            if (InputBuffer == null)
                throw new ArgumentNullException("Buffer is empty");

            return ComputeHash(InputBuffer, 0, InputBuffer.Length);
        }

        /// <summary>
        /// Computes the hash value for a block of bytes
        /// </summary>
        /// <param name="InputBuffer">Input buffer [bytes[]]</param>
        /// <param name="InputOffset">Start Position within the input buffer</param>
        /// <param name="InputCount">Number of bytes to be processed</param>
        /// <returns>Returns hash value [byte array]</returns>
        internal byte[] ComputeHash(byte[] InputBuffer, int InputOffset, int InputCount)
        {
            if (InputBuffer == null)
                throw new ArgumentNullException("The Buffer is null");
            if (InputOffset > InputBuffer.Length - InputCount)
                throw new ArgumentException("Offset is more then buffer length");

            HashCore(InputBuffer, InputOffset, InputCount);
            _hashValue = HashFinal();
            Initialize();

            return _hashValue;
        }

        /// <summary>
        /// Computes the hash value from an input stream
        /// </summary>
        /// <param name="InputStream">Input stream [Stream]</param>
        /// <returns>Returns hash value [byte array]</returns>
        internal byte[] ComputeHash(Stream InputStream)
        {
            if (InputStream == null)
                throw new ArgumentNullException("The Stream is null");
            if (InputStream.Length < 4096)
                throw new ArgumentNullException("The Stream is too small");

            byte[] buffer = new byte[4096];
            int len = InputStream.Read(buffer, 0, 4096);

            while (len > 0)
            {
                HashCore(buffer, 0, len);
                len = InputStream.Read(buffer, 0, 4096);
            }

            _hashValue = HashFinal();
            Initialize();

            return _hashValue;
        }

        /// <summary>
        /// Transforms a block of bytes
        /// </summary>
        /// <param name="InputBuffer">Input buffer [bytes[]]</param>
        /// <param name="InputOffset">Start Position within the input buffer</param>
        /// <param name="InputCount">Number of bytes to be processed</param>
        /// <param name="OutputBuffer">Buffer that receives the transformed bytes</param>
        /// <param name="OutputOffset">Starting position witin the output buffer</param>
        /// <returns>Bytes processed [int]</returns>
        internal int TransformBlock(byte[] InputBuffer, int InputOffset, int InputCount, byte[] OutputBuffer, int OutputOffset)
        {
            if (InputBuffer == null)
                throw new ArgumentNullException("InputBuffer can not be null!");
            if (InputOffset < 0)
                throw new ArgumentOutOfRangeException("InputOffset is less then 0");
            if (InputCount < 0)
                throw new ArgumentException("InputCount is invalid");
            if ((InputOffset < 0) || (InputOffset > InputBuffer.Length - InputCount))
                throw new ArgumentException("InputOffset + InputCount is invalid");
            if (OutputOffset < 0)
                throw new ArgumentOutOfRangeException("OutputOffset is invalid");
            if (OutputOffset > OutputBuffer.Length - InputCount)
                throw new ArgumentException("OutputOffset + InputCount will Overflow");

            HashCore(InputBuffer, InputOffset, InputCount);

            if (OutputBuffer != null)
                Buffer.BlockCopy(InputBuffer, InputOffset, OutputBuffer, OutputOffset, InputCount);

            return InputCount;
        }

        /// <summary>
        /// Transform the final block of bytes
        /// </summary>
        /// <param name="InputBuffer">Input buffer [bytes[]]</param>
        /// <param name="InputOffset">Start Position within the input buffer</param>
        /// <param name="InputCount">Number of bytes to be processed</param>
        /// <returns>Returns hash value [byte array]</returns>
        internal byte[] TransformFinalBlock(byte[] InputBuffer, int InputOffset, int InputCount)
        {
            if (InputBuffer == null)
                throw new ArgumentNullException("InputBuffer can not be null!");
            if (InputCount < 0)
                throw new ArgumentException("InputCount is invalid");
            if (InputOffset > InputBuffer.Length - InputCount)
                throw new ArgumentException("InputOffset + InputCount will Overflow");

            byte[] outputBuffer = new byte[InputCount];

            Buffer.BlockCopy(InputBuffer, InputOffset, outputBuffer, 0, InputCount);
            HashCore(InputBuffer, InputOffset, InputCount);
            _hashValue = HashFinal();
            Initialize();

            return outputBuffer;
        }
        #endregion

        #region Private Methods
        private void HashCore(byte[] RGB, int Start, int Size)
        {
            if (_processingBufferCount != 0)
            {
                if (Size < (BLOCK_BYTES - _processingBufferCount))
                {
                    Buffer.BlockCopy(RGB, Start, _processingBuffer, _processingBufferCount, Size);
                    _processingBufferCount += Size;
                    return;
                }
                else
                {
                    int len = (BLOCK_BYTES - _processingBufferCount);
                    Buffer.BlockCopy(RGB, Start, _processingBuffer, _processingBufferCount, len);
                    ProcessBlock(_processingBuffer, 0);
                    _processingBufferCount = 0;
                    Start += len;
                    Size -= len;
                }
            }

            for (int i = 0; i < Size - (Size % BLOCK_BYTES); i += BLOCK_BYTES)
                ProcessBlock(RGB, Start + i);

            if (Size % BLOCK_BYTES != 0)
            {
                Buffer.BlockCopy(RGB, Size - Size % BLOCK_BYTES + Start, _processingBuffer, 0, Size % BLOCK_BYTES);
                _processingBufferCount = Size % BLOCK_BYTES;
            }
        }

        private byte[] HashFinal()
        {
            byte[] hash = new byte[32];
            int i, j;

            ProcessFinalBlock(_processingBuffer, 0, _processingBufferCount);

            for (i = 0; i < 8; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    hash[i * 4 + j] = (byte)(_hashBuffer[i] >> (24 - j * 8));
                }
            }

            return hash;
        }

        private void Initialize()
        {
            _blockCount = 0;
            _processingBufferCount = 0;
            _hashBuffer = new UInt32[8] { 0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A, 0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19 };
        }

        private void AddLength(ulong length, byte[] buffer, int position)
        {
            buffer[position++] = (byte)(length >> 56);
            buffer[position++] = (byte)(length >> 48);
            buffer[position++] = (byte)(length >> 40);
            buffer[position++] = (byte)(length >> 32);
            buffer[position++] = (byte)(length >> 24);
            buffer[position++] = (byte)(length >> 16);
            buffer[position++] = (byte)(length >> 8);
            buffer[position] = (byte)(length);
        }

        private void ProcessBlock(byte[] inputBuffer, int inputOffset)
        {
            uint t1, t2;
            uint[] buff = new uint[64];
            uint[] temp = _hashBuffer;

            _blockCount += BLOCK_BYTES;

            for (int i = 0; i < 16; i++)
            {
                buff[i] = (uint)(((inputBuffer[inputOffset + 4 * i]) << 24)
                    | ((inputBuffer[inputOffset + 4 * i + 1]) << 16)
                    | ((inputBuffer[inputOffset + 4 * i + 2]) << 8)
                    | ((inputBuffer[inputOffset + 4 * i + 3])));
            }

            for (int i = 16; i < 64; i++)
            {
                t1 = buff[i - 15];
                t1 = (((t1 >> 7) | (t1 << 25)) ^ ((t1 >> 18) | (t1 << 14)) ^ (t1 >> 3));
                t2 = buff[i - 2];
                t2 = (((t2 >> 17) | (t2 << 15)) ^ ((t2 >> 19) | (t2 << 13)) ^ (t2 >> 10));
                buff[i] = t2 + buff[i - 7] + t1 + buff[i - 16];
            }

            for (int i = 0; i < 64; i++)
            {
                t1 = temp[7] + (((temp[4] >> 6) | (temp[4] << 26)) ^ ((temp[4] >> 11) | (temp[4] << 21)) ^ ((temp[4] >> 25) | (temp[4] << 7))) + ((temp[4] & temp[5]) ^ (~temp[4] & temp[6])) + K1CT[i] + buff[i];
                t2 = (((temp[0] >> 2) | (temp[0] << 30)) ^ ((temp[0] >> 13) | (temp[0] << 19)) ^ ((temp[0] >> 22) | (temp[0] << 10)));
                t2 = t2 + ((temp[0] & temp[1]) ^ (temp[0] & temp[2]) ^ (temp[1] & temp[2]));
                temp[7] = temp[6];
                temp[6] = temp[5];
                temp[5] = temp[4];
                temp[4] = temp[3] + t1;
                temp[3] = temp[2];
                temp[2] = temp[1];
                temp[1] = temp[0];
                temp[0] = t1 + t2;
            }

            _hashBuffer[0] += temp[0];
            _hashBuffer[1] += temp[1];
            _hashBuffer[2] += temp[2];
            _hashBuffer[3] += temp[3];
            _hashBuffer[4] += temp[4];
            _hashBuffer[5] += temp[5];
            _hashBuffer[6] += temp[6];
            _hashBuffer[7] += temp[7];
        }

        private void ProcessFinalBlock(byte[] inputBuffer, int inputOffset, int inputCount)
        {
            ulong total = _blockCount + (ulong)inputCount;
            int paddingSize = (56 - (int)(total % BLOCK_BYTES));

            if (paddingSize < 1)
                paddingSize += BLOCK_BYTES;

            byte[] temp = new byte[inputCount + paddingSize + 8];

            for (int i = 0; i < inputCount; i++)
                temp[i] = inputBuffer[i + inputOffset];

            temp[inputCount] = 0x80;

            for (int i = inputCount + 1; i < inputCount + paddingSize; i++)
                temp[i] = 0x00;

            // the algorithm uses bits
            ulong size = total << 3;
            AddLength(size, temp, inputCount + paddingSize);
            ProcessBlock(temp, 0);

            if (inputCount + paddingSize + 8 == 128)
                ProcessBlock(temp, 64);
        }
        #endregion

        #region IDisposable
        internal void Dispose()
        {
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (!_isDisposed)
            {
                if (disposing)
                {
                    if (_hashBuffer != null)
                        Array.Clear(_hashBuffer, 0, _hashBuffer.Length);
                    if (_processingBuffer != null)
                        Array.Clear(_processingBuffer, 0, _processingBuffer.Length);
                    _processingBufferCount = 0;
                }
                _isDisposed = true;
            }
        }

        void IDisposable.Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

        #region K1 Constants
        // first 32 bits of the fractional parts of the cube roots of first sixty-four prime numbers
        private readonly uint[] K1CT = { 
            0x428A2F98, 0x71374491, 0xB5C0FBCF, 0xE9B5DBA5, 0x3956C25B, 0x59F111F1, 0x923F82A4, 0xAB1C5ED5,
            0xD807AA98, 0x12835B01, 0x243185BE, 0x550C7DC3, 0x72BE5D74, 0x80DEB1FE, 0x9BDC06A7, 0xC19BF174,
            0xE49B69C1, 0xEFBE4786, 0x0FC19DC6, 0x240CA1CC, 0x2DE92C6F, 0x4A7484AA, 0x5CB0A9DC, 0x76F988DA,
            0x983E5152, 0xA831C66D, 0xB00327C8, 0xBF597FC7, 0xC6E00BF3, 0xD5A79147, 0x06CA6351, 0x14292967,
            0x27B70A85, 0x2E1B2138, 0x4D2C6DFC, 0x53380D13, 0x650A7354, 0x766A0ABB, 0x81C2C92E, 0x92722C85,
            0xA2BFE8A1, 0xA81A664B, 0xC24B8B70, 0xC76C51A3, 0xD192E819, 0xD6990624, 0xF40E3585, 0x106AA070,
            0x19A4C116, 0x1E376C08, 0x2748774C, 0x34B0BCB5, 0x391C0CB3, 0x4ED8AA4A, 0x5B9CCA4F, 0x682E6FF3,
            0x748F82EE, 0x78A5636F, 0x84C87814, 0x8CC70208, 0x90BEFFFA, 0xA4506CEB, 0xBEF9A3F7, 0xC67178F2
        };
        #endregion
    }
}
