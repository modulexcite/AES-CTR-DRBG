﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drbg_Test
{
    internal static class Tools
    {
        /*private void SeedTableGenerator()
        {
            byte[] data = CSPRNG.GetSeed64Xs();
            string byteStr = string.Empty;

            for (int i = 1; i < 65; i++)
            {
                byteStr += String.Format("0x{0:X}", data[i - 1]) + ", ";
                if (i % 8 == 0 && i > 0)
                {
                    Console.WriteLine(byteStr);
                    byteStr = string.Empty;
                }
            }
        }

        private void TableGenerator()
        {
            byte[] data = GetRandomBlockChaotic(4096);
            UInt32[] numArr = new UInt32[1024];
            Buffer.BlockCopy(data, 0, numArr, 0, 4096);
            string numStr = string.Empty;

            for (int i = 1; i < 1025; i++)
            {
                numStr += String.Format("0x{0:X}", numArr[i - 1]) + ", ";
                if (i % 8 == 0 && i > 0)
                {
                    Console.WriteLine(numStr);
                    numStr = string.Empty;
                }
            }
        }

        private void CamelliaTest()
        {
            byte[] key = CSPRNG.GetSeed32();
            byte[] test1 = CSPRNG.GetSeed16();
            byte[] ret = new byte[16];

            Camellia cn = new Camellia();
            byte[] enc = cn.EncryptTest(test1, key);

            CamelliaLightEngine co = new CamelliaLightEngine();
            co.Init(false, key);
            co.ProcessBlock(enc, 0, ret, 0);

            if (!ret.SequenceEqual(test1))
                throw new Exception("Problem!");
        }

        private void TwoFishTest()
        {
            byte[] key = CSPRNG.GetSeed32();
            byte[] data = CSPRNG.GetSeed16();
            byte[] enc = new byte[16];
            byte[] output = new byte[16];

            Twofish tw = new Twofish();
            int[] k = tw.TFExpandKey(key);
            tw.EncryptBlock(data, 0, enc, 0, k);

            TwofishOld to = new TwofishOld();
            to.Init(false, key);
            to.ProcessBlock(enc, 0, output, 0);

            if (!data.SequenceEqual(output))
                throw new Exception("Wrong!");
        }*/
    }
}
