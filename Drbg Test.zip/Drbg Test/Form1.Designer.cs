﻿namespace Drbg_Test
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTestAesCtr = new System.Windows.Forms.Button();
            this.btnDialog = new System.Windows.Forms.Button();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pbStatus = new System.Windows.Forms.ProgressBar();
            this.grpOutput = new System.Windows.Forms.GroupBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblStatus = new System.Windows.Forms.Label();
            this.grpChoice = new System.Windows.Forms.GroupBox();
            this.rdAes800 = new System.Windows.Forms.RadioButton();
            this.rdRng = new System.Windows.Forms.RadioButton();
            this.grpModes = new System.Windows.Forms.GroupBox();
            this.rdChaotic = new System.Windows.Forms.RadioButton();
            this.rdCtrChain = new System.Windows.Forms.RadioButton();
            this.rdOscillating = new System.Windows.Forms.RadioButton();
            this.rdCycling = new System.Windows.Forms.RadioButton();
            this.rdAutoeed = new System.Windows.Forms.RadioButton();
            this.grpParamaters = new System.Windows.Forms.GroupBox();
            this.chkSummary = new System.Windows.Forms.CheckBox();
            this.cbSampleSize = new System.Windows.Forms.ComboBox();
            this.cbTestIterations = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblStatAes = new System.Windows.Forms.Label();
            this.lblStatOpponent = new System.Windows.Forms.Label();
            this.grpOutput.SuspendLayout();
            this.grpChoice.SuspendLayout();
            this.grpModes.SuspendLayout();
            this.grpParamaters.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnTestAesCtr
            // 
            this.btnTestAesCtr.Location = new System.Drawing.Point(423, 303);
            this.btnTestAesCtr.Name = "btnTestAesCtr";
            this.btnTestAesCtr.Size = new System.Drawing.Size(75, 30);
            this.btnTestAesCtr.TabIndex = 0;
            this.btnTestAesCtr.Text = "Run Tests";
            this.btnTestAesCtr.UseVisualStyleBackColor = true;
            this.btnTestAesCtr.Click += new System.EventHandler(this.OnTestClick);
            // 
            // btnDialog
            // 
            this.btnDialog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDialog.Location = new System.Drawing.Point(450, 19);
            this.btnDialog.Name = "btnDialog";
            this.btnDialog.Size = new System.Drawing.Size(30, 30);
            this.btnDialog.TabIndex = 1;
            this.btnDialog.Text = "...";
            this.btnDialog.UseVisualStyleBackColor = true;
            this.btnDialog.Click += new System.EventHandler(this.OnDialogClick);
            // 
            // txtOutput
            // 
            this.txtOutput.Location = new System.Drawing.Point(6, 24);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(438, 20);
            this.txtOutput.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(375, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Run an ENT comparison between AesCtr and common Algorithms";
            // 
            // pbStatus
            // 
            this.pbStatus.Location = new System.Drawing.Point(0, 347);
            this.pbStatus.Name = "pbStatus";
            this.pbStatus.Size = new System.Drawing.Size(206, 16);
            this.pbStatus.TabIndex = 4;
            // 
            // grpOutput
            // 
            this.grpOutput.Controls.Add(this.btnDialog);
            this.grpOutput.Controls.Add(this.txtOutput);
            this.grpOutput.Location = new System.Drawing.Point(12, 32);
            this.grpOutput.Name = "grpOutput";
            this.grpOutput.Size = new System.Drawing.Size(486, 62);
            this.grpOutput.TabIndex = 5;
            this.grpOutput.TabStop = false;
            this.grpOutput.Text = "Output File";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 345);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(510, 22);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(211, 349);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(52, 13);
            this.lblStatus.TabIndex = 7;
            this.lblStatus.Text = "Waiting...";
            // 
            // grpChoice
            // 
            this.grpChoice.Controls.Add(this.rdAes800);
            this.grpChoice.Controls.Add(this.rdRng);
            this.grpChoice.Location = new System.Drawing.Point(12, 150);
            this.grpChoice.Name = "grpChoice";
            this.grpChoice.Size = new System.Drawing.Size(486, 44);
            this.grpChoice.TabIndex = 8;
            this.grpChoice.TabStop = false;
            this.grpChoice.Text = "Entropy Compare AesCtr With:";
            // 
            // rdAes800
            // 
            this.rdAes800.AutoSize = true;
            this.rdAes800.Location = new System.Drawing.Point(167, 21);
            this.rdAes800.Name = "rdAes800";
            this.rdAes800.Size = new System.Drawing.Size(84, 17);
            this.rdAes800.TabIndex = 1;
            this.rdAes800.Text = "Aes800Drbg";
            this.rdAes800.UseVisualStyleBackColor = true;
            this.rdAes800.CheckedChanged += new System.EventHandler(this.OnCheckChanged);
            // 
            // rdRng
            // 
            this.rdRng.AutoSize = true;
            this.rdRng.Checked = true;
            this.rdRng.Location = new System.Drawing.Point(7, 20);
            this.rdRng.Name = "rdRng";
            this.rdRng.Size = new System.Drawing.Size(154, 17);
            this.rdRng.TabIndex = 0;
            this.rdRng.TabStop = true;
            this.rdRng.Text = "RNGCryptoServiceProvider";
            this.rdRng.UseVisualStyleBackColor = true;
            this.rdRng.CheckedChanged += new System.EventHandler(this.OnCheckChanged);
            // 
            // grpModes
            // 
            this.grpModes.Controls.Add(this.rdChaotic);
            this.grpModes.Controls.Add(this.rdCtrChain);
            this.grpModes.Controls.Add(this.rdOscillating);
            this.grpModes.Controls.Add(this.rdCycling);
            this.grpModes.Controls.Add(this.rdAutoeed);
            this.grpModes.Location = new System.Drawing.Point(12, 100);
            this.grpModes.Name = "grpModes";
            this.grpModes.Size = new System.Drawing.Size(486, 44);
            this.grpModes.TabIndex = 9;
            this.grpModes.TabStop = false;
            this.grpModes.Text = "AesCtr Generation Mode";
            // 
            // rdChaotic
            // 
            this.rdChaotic.AutoSize = true;
            this.rdChaotic.Location = new System.Drawing.Point(384, 19);
            this.rdChaotic.Name = "rdChaotic";
            this.rdChaotic.Size = new System.Drawing.Size(99, 17);
            this.rdChaotic.TabIndex = 4;
            this.rdChaotic.Text = "Chaotic Re-Key";
            this.rdChaotic.UseVisualStyleBackColor = true;
            // 
            // rdCtrChain
            // 
            this.rdCtrChain.AutoSize = true;
            this.rdCtrChain.Location = new System.Drawing.Point(310, 19);
            this.rdCtrChain.Name = "rdCtrChain";
            this.rdCtrChain.Size = new System.Drawing.Size(68, 17);
            this.rdCtrChain.TabIndex = 3;
            this.rdCtrChain.Text = "Ctr Chain";
            this.rdCtrChain.UseVisualStyleBackColor = true;
            // 
            // rdOscillating
            // 
            this.rdOscillating.AutoSize = true;
            this.rdOscillating.Location = new System.Drawing.Point(210, 19);
            this.rdOscillating.Name = "rdOscillating";
            this.rdOscillating.Size = new System.Drawing.Size(94, 17);
            this.rdOscillating.TabIndex = 2;
            this.rdOscillating.Text = "Key Oscillation";
            this.rdOscillating.UseVisualStyleBackColor = true;
            this.rdOscillating.CheckedChanged += new System.EventHandler(this.OnCheckChanged);
            // 
            // rdCycling
            // 
            this.rdCycling.AutoSize = true;
            this.rdCycling.Checked = true;
            this.rdCycling.Location = new System.Drawing.Point(88, 19);
            this.rdCycling.Name = "rdCycling";
            this.rdCycling.Size = new System.Drawing.Size(110, 17);
            this.rdCycling.TabIndex = 1;
            this.rdCycling.TabStop = true;
            this.rdCycling.Text = "Cycling Key Chain";
            this.rdCycling.UseVisualStyleBackColor = true;
            this.rdCycling.CheckedChanged += new System.EventHandler(this.OnCheckChanged);
            // 
            // rdAutoeed
            // 
            this.rdAutoeed.AutoSize = true;
            this.rdAutoeed.Location = new System.Drawing.Point(7, 20);
            this.rdAutoeed.Name = "rdAutoeed";
            this.rdAutoeed.Size = new System.Drawing.Size(75, 17);
            this.rdAutoeed.TabIndex = 0;
            this.rdAutoeed.Text = "Auto Seed";
            this.rdAutoeed.UseVisualStyleBackColor = true;
            this.rdAutoeed.CheckedChanged += new System.EventHandler(this.OnCheckChanged);
            // 
            // grpParamaters
            // 
            this.grpParamaters.Controls.Add(this.chkSummary);
            this.grpParamaters.Controls.Add(this.cbSampleSize);
            this.grpParamaters.Controls.Add(this.cbTestIterations);
            this.grpParamaters.Controls.Add(this.label4);
            this.grpParamaters.Controls.Add(this.label3);
            this.grpParamaters.Controls.Add(this.label2);
            this.grpParamaters.Location = new System.Drawing.Point(11, 200);
            this.grpParamaters.Name = "grpParamaters";
            this.grpParamaters.Size = new System.Drawing.Size(487, 92);
            this.grpParamaters.TabIndex = 10;
            this.grpParamaters.TabStop = false;
            this.grpParamaters.Text = "Test Parameters";
            // 
            // chkSummary
            // 
            this.chkSummary.AutoSize = true;
            this.chkSummary.Location = new System.Drawing.Point(8, 69);
            this.chkSummary.Name = "chkSummary";
            this.chkSummary.Size = new System.Drawing.Size(119, 17);
            this.chkSummary.TabIndex = 11;
            this.chkSummary.Text = "Write Summary only";
            this.chkSummary.UseVisualStyleBackColor = true;
            // 
            // cbSampleSize
            // 
            this.cbSampleSize.FormattingEnabled = true;
            this.cbSampleSize.Items.AddRange(new object[] {
            "1",
            "10",
            "100",
            "1000"});
            this.cbSampleSize.Location = new System.Drawing.Point(89, 36);
            this.cbSampleSize.Name = "cbSampleSize";
            this.cbSampleSize.Size = new System.Drawing.Size(62, 21);
            this.cbSampleSize.TabIndex = 6;
            this.cbSampleSize.Text = "100";
            this.cbSampleSize.SelectedValueChanged += new System.EventHandler(this.OnSelectedValueChanged);
            // 
            // cbTestIterations
            // 
            this.cbTestIterations.FormattingEnabled = true;
            this.cbTestIterations.Items.AddRange(new object[] {
            "1",
            "10",
            "100",
            "1000",
            "10000"});
            this.cbTestIterations.Location = new System.Drawing.Point(8, 36);
            this.cbTestIterations.Name = "cbTestIterations";
            this.cbTestIterations.Size = new System.Drawing.Size(62, 21);
            this.cbTestIterations.TabIndex = 5;
            this.cbTestIterations.Text = "1000";
            this.cbTestIterations.SelectedValueChanged += new System.EventHandler(this.OnSelectedValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(152, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "* Kib (1024 bytes)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(89, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Sample Size:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Iterations";
            // 
            // lblStatAes
            // 
            this.lblStatAes.AutoSize = true;
            this.lblStatAes.Location = new System.Drawing.Point(12, 320);
            this.lblStatAes.Name = "lblStatAes";
            this.lblStatAes.Size = new System.Drawing.Size(25, 13);
            this.lblStatAes.TabIndex = 11;
            this.lblStatAes.Text = "......";
            // 
            // lblStatOpponent
            // 
            this.lblStatOpponent.AutoSize = true;
            this.lblStatOpponent.Location = new System.Drawing.Point(181, 320);
            this.lblStatOpponent.Name = "lblStatOpponent";
            this.lblStatOpponent.Size = new System.Drawing.Size(25, 13);
            this.lblStatOpponent.TabIndex = 12;
            this.lblStatOpponent.Text = "......";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 367);
            this.Controls.Add(this.lblStatOpponent);
            this.Controls.Add(this.lblStatAes);
            this.Controls.Add(this.grpParamaters);
            this.Controls.Add(this.grpModes);
            this.Controls.Add(this.grpChoice);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.pbStatus);
            this.Controls.Add(this.btnTestAesCtr);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.grpOutput);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.grpOutput.ResumeLayout(false);
            this.grpOutput.PerformLayout();
            this.grpChoice.ResumeLayout(false);
            this.grpChoice.PerformLayout();
            this.grpModes.ResumeLayout(false);
            this.grpModes.PerformLayout();
            this.grpParamaters.ResumeLayout(false);
            this.grpParamaters.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTestAesCtr;
        private System.Windows.Forms.Button btnDialog;
        private System.Windows.Forms.TextBox txtOutput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar pbStatus;
        private System.Windows.Forms.GroupBox grpOutput;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.GroupBox grpChoice;
        private System.Windows.Forms.RadioButton rdAes800;
        private System.Windows.Forms.RadioButton rdRng;
        private System.Windows.Forms.GroupBox grpModes;
        private System.Windows.Forms.RadioButton rdOscillating;
        private System.Windows.Forms.RadioButton rdCycling;
        private System.Windows.Forms.RadioButton rdAutoeed;
        private System.Windows.Forms.GroupBox grpParamaters;
        private System.Windows.Forms.ComboBox cbSampleSize;
        private System.Windows.Forms.ComboBox cbTestIterations;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkSummary;
        private System.Windows.Forms.Label lblStatAes;
        private System.Windows.Forms.Label lblStatOpponent;
        private System.Windows.Forms.RadioButton rdCtrChain;
        private System.Windows.Forms.RadioButton rdChaotic;
    }
}

