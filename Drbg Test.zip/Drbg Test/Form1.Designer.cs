﻿namespace Drbg_Test
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTestAesCtr = new System.Windows.Forms.Button();
            this.btnDialog = new System.Windows.Forms.Button();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pbStatus = new System.Windows.Forms.ProgressBar();
            this.grpBox = new System.Windows.Forms.GroupBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblStatus = new System.Windows.Forms.Label();
            this.grpChoice = new System.Windows.Forms.GroupBox();
            this.rdRng = new System.Windows.Forms.RadioButton();
            this.rdAes800 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdRotating = new System.Windows.Forms.RadioButton();
            this.rdAutoeed = new System.Windows.Forms.RadioButton();
            this.rdOscillating = new System.Windows.Forms.RadioButton();
            this.grpBox.SuspendLayout();
            this.grpChoice.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnTestAesCtr
            // 
            this.btnTestAesCtr.Location = new System.Drawing.Point(350, 206);
            this.btnTestAesCtr.Name = "btnTestAesCtr";
            this.btnTestAesCtr.Size = new System.Drawing.Size(75, 30);
            this.btnTestAesCtr.TabIndex = 0;
            this.btnTestAesCtr.Text = "Run Tests";
            this.btnTestAesCtr.UseVisualStyleBackColor = true;
            this.btnTestAesCtr.Click += new System.EventHandler(this.OnTestClick);
            // 
            // btnDialog
            // 
            this.btnDialog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDialog.Location = new System.Drawing.Point(377, 19);
            this.btnDialog.Name = "btnDialog";
            this.btnDialog.Size = new System.Drawing.Size(30, 30);
            this.btnDialog.TabIndex = 1;
            this.btnDialog.Text = "...";
            this.btnDialog.UseVisualStyleBackColor = true;
            this.btnDialog.Click += new System.EventHandler(this.OnDialogClick);
            // 
            // txtOutput
            // 
            this.txtOutput.Location = new System.Drawing.Point(6, 24);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(365, 20);
            this.txtOutput.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(375, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Run an ENT comparison between AesCtr and common Algorithms";
            // 
            // pbStatus
            // 
            this.pbStatus.Location = new System.Drawing.Point(1, 252);
            this.pbStatus.Name = "pbStatus";
            this.pbStatus.Size = new System.Drawing.Size(206, 16);
            this.pbStatus.TabIndex = 4;
            // 
            // grpBox
            // 
            this.grpBox.Controls.Add(this.btnDialog);
            this.grpBox.Controls.Add(this.txtOutput);
            this.grpBox.Location = new System.Drawing.Point(12, 32);
            this.grpBox.Name = "grpBox";
            this.grpBox.Size = new System.Drawing.Size(413, 62);
            this.grpBox.TabIndex = 5;
            this.grpBox.TabStop = false;
            this.grpBox.Text = "Output File";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 249);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(436, 22);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(357, 254);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(52, 13);
            this.lblStatus.TabIndex = 7;
            this.lblStatus.Text = "Waiting...";
            // 
            // grpChoice
            // 
            this.grpChoice.Controls.Add(this.rdAes800);
            this.grpChoice.Controls.Add(this.rdRng);
            this.grpChoice.Location = new System.Drawing.Point(12, 150);
            this.grpChoice.Name = "grpChoice";
            this.grpChoice.Size = new System.Drawing.Size(412, 44);
            this.grpChoice.TabIndex = 8;
            this.grpChoice.TabStop = false;
            this.grpChoice.Text = "Entropy Compare AesCtr With:";
            // 
            // rdRng
            // 
            this.rdRng.AutoSize = true;
            this.rdRng.Checked = true;
            this.rdRng.Location = new System.Drawing.Point(7, 20);
            this.rdRng.Name = "rdRng";
            this.rdRng.Size = new System.Drawing.Size(154, 17);
            this.rdRng.TabIndex = 0;
            this.rdRng.TabStop = true;
            this.rdRng.Text = "RNGCryptoServiceProvider";
            this.rdRng.UseVisualStyleBackColor = true;
            this.rdRng.CheckedChanged += new System.EventHandler(this.OnCheckChanged);
            // 
            // rdAes800
            // 
            this.rdAes800.AutoSize = true;
            this.rdAes800.Location = new System.Drawing.Point(167, 21);
            this.rdAes800.Name = "rdAes800";
            this.rdAes800.Size = new System.Drawing.Size(84, 17);
            this.rdAes800.TabIndex = 1;
            this.rdAes800.Text = "Aes800Drbg";
            this.rdAes800.UseVisualStyleBackColor = true;
            this.rdAes800.CheckedChanged += new System.EventHandler(this.OnCheckChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdOscillating);
            this.groupBox1.Controls.Add(this.rdRotating);
            this.groupBox1.Controls.Add(this.rdAutoeed);
            this.groupBox1.Location = new System.Drawing.Point(12, 100);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(412, 44);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "AesCtr Generation Mode";
            // 
            // rdRotating
            // 
            this.rdRotating.AutoSize = true;
            this.rdRotating.Checked = true;
            this.rdRotating.Location = new System.Drawing.Point(103, 19);
            this.rdRotating.Name = "rdRotating";
            this.rdRotating.Size = new System.Drawing.Size(116, 17);
            this.rdRotating.TabIndex = 1;
            this.rdRotating.TabStop = true;
            this.rdRotating.Text = "Rotating Key Chain";
            this.rdRotating.UseVisualStyleBackColor = true;
            this.rdRotating.CheckedChanged += new System.EventHandler(this.OnCheckChanged);
            // 
            // rdAutoeed
            // 
            this.rdAutoeed.AutoSize = true;
            this.rdAutoeed.Location = new System.Drawing.Point(7, 20);
            this.rdAutoeed.Name = "rdAutoeed";
            this.rdAutoeed.Size = new System.Drawing.Size(75, 17);
            this.rdAutoeed.TabIndex = 0;
            this.rdAutoeed.Text = "Auto Seed";
            this.rdAutoeed.UseVisualStyleBackColor = true;
            this.rdAutoeed.CheckedChanged += new System.EventHandler(this.OnCheckChanged);
            // 
            // rdOscillating
            // 
            this.rdOscillating.AutoSize = true;
            this.rdOscillating.Location = new System.Drawing.Point(237, 19);
            this.rdOscillating.Name = "rdOscillating";
            this.rdOscillating.Size = new System.Drawing.Size(94, 17);
            this.rdOscillating.TabIndex = 2;
            this.rdOscillating.Text = "Key Oscillation";
            this.rdOscillating.UseVisualStyleBackColor = true;
            this.rdOscillating.CheckedChanged += new System.EventHandler(this.OnCheckChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 271);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grpChoice);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.pbStatus);
            this.Controls.Add(this.btnTestAesCtr);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.grpBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.grpBox.ResumeLayout(false);
            this.grpBox.PerformLayout();
            this.grpChoice.ResumeLayout(false);
            this.grpChoice.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTestAesCtr;
        private System.Windows.Forms.Button btnDialog;
        private System.Windows.Forms.TextBox txtOutput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar pbStatus;
        private System.Windows.Forms.GroupBox grpBox;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.GroupBox grpChoice;
        private System.Windows.Forms.RadioButton rdAes800;
        private System.Windows.Forms.RadioButton rdRng;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdOscillating;
        private System.Windows.Forms.RadioButton rdRotating;
        private System.Windows.Forms.RadioButton rdAutoeed;
    }
}

